# English Sarcasm Examples

This file is converted from `train.En.csv`. Each item contains a sarcastic text, its dataset label, optional sarcasm type, and a non-sarcastic rephrase when available.

Use this file as `knowledge_base/sarcasm_examples.md` in the Sentiment RAG project.

## Example 1

Text: The only thing I got from college is a caffeine addiction

Label: sarcastic

Sarcasm Type: irony

Meaning: College is really difficult, expensive, tiring, and I often question if a degree is worth the stress.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 2

Text: I love it when professors draw a big question mark next to my answer on an exam because I’m always like yeah I don’t either ¯\_(ツ)_/¯

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I do not like when professors don’t write out specific notes on my answers to exams.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 3

Text: Remember the hundred emails from companies when Covid started getting real? I’ve gotten three in regards to support for protests. And only @SavageXFenty shared helpful links and actually said black lives matter... we love capitalism 🥰🙌🏼

Label: sarcastic

Sarcasm Type: irony

Meaning: I, at the bare minimum, wish companies actually cared about marginalized communities. At the max, that our capitalistic society is dismantled.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 4

Text: Today my pop-pop told me I was not “forced” to go to college 🙃 okay sure sureeee

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Today my pop-pop told me I was not "forced" to go to college. That's not true.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 5

Text: @VolphanCarol @littlewhitty @mysticalmanatee I did too, and I also reported Cancun Cruz not worrying about the heartbeats of his constituents without electricity or heat when he fled to Mexico.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say Ted Cruz is an asshole and doesn’t actually care about people/babies/fetuses. He just wants to wage a war on women and keep the patriarchy in power.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 6

Text: @jimrossignol I choose to interpret it as "XD": the universal emoticon for laughing at those poor, poor folks in Ubisoft's marketing department who have to deal with that branding until the servers quietly shut down 8 months after launch.

Label: sarcastic

Sarcasm Type: irony, understatement

Meaning: It's a terrible name and the product sounds awful.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 7

Text: Why would Alexa's recipe for Yorkshire pudding be a bhaji yorkshire pudding ?? @bbcgoodfood

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: Great recipe from Alexa

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 8

Text: someone hit me w a horse tranquilizer istg ive been in a pool of sweat for 6 hours and i havent slept im so tired but i love my friend so much and oh my fucking god i cant rn

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Simply “I’m miserable.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 9

Text: Loving season 4 of trump does America. Funniest season yet #DonaldTrump #Trump #MAGA #MAGA2020

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: this last year of trumps presidency is not going too well

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 10

Text: Holly Arnold ??? Who #ImACeleb #MBE nope not sure oh hang on you mean MBE yes that’s her !!!

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Holly Arnold seem like a nice lady, just feel that keeping on about having an MBE may start to annoy her fans.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 11

Text: ANY PENSIONER AND 4 YEAR OLD WHO DARE TAKE ME ON AT DINOSAUR THEMED CRAZY GOLF WILL BE CRUSHED, CRUSHED I TELL YOU. https://t.co/yZlafy0lsd

Label: sarcastic

Sarcasm Type: irony

Meaning: Had a great time playing crazy golf with the family, and I won!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 12

Text: See Brexit is going well

Label: sarcastic

Sarcasm Type: irony

Meaning: Brexit really isn't going to plan.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 13

Text: Just like to congratulate everyone on the Kop today for the fastest ever Poor Scouser Tommy. Slow the fuck down

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Can we not sing poor scouser tommy abit slower instead of super fast

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 14

Text: do i just blast maneskin to get hyped for my osce or??

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I probably shouldn't be listening to Maneskin before my OSCE, it's not the right vibe.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 15

Text: @heathoween @tylerrjoseph Yes, because we need literally every single fucking celebrity to speak up on a topic that's been forced down everyone's throats for the past four months. I use the internet to get away from these fucking real life problems; not everyone needs to weigh in.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Not every celebrity needs to weigh in on every political issue there is"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 16

Text: I never thought I'd say this, but I have become one of those people who like bounty bars.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: No, it would be less logical.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 17

Text: My eldest is having a wild Friday night out. She's going to bingo. 😂

Label: sarcastic

Sarcasm Type: sarcasm, irony

Meaning: My eldest is going to play bingo tonight.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 18

Text: Whoever’s toddler ass sprayed the entire toilet backstage, I hope you stub your toe and bite your tongue really hard. also you were clearly dehydrated, go drink some damn water like an adult

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hope whoever keeps peeing all over the bathroom at work stops doing that.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 19

Text: gaslight gatekeep girl boss

Label: sarcastic

Sarcasm Type: irony

Meaning: I do not gaslight, gatekeep, or am a girl boss.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 20

Text: I was only in Taylor Swift’s top 0.10% of listeners on Spotify but last year but yeah totally sound that Swiftogeddan in Glasgow is sold out

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am not happy that I didn't get tickets to the Swiftogeddan event when I should be there instead of most people who bought tickets.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 21

Text: Imagine going to university for 4 years when you could just follow Elon Musk on twitter for free

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Go to school

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 22

Text: Not got one lynx Africa for Christmas Day this year, shocked and outraged. #RuinedChristmas

Label: sarcastic

Sarcasm Type: irony

Meaning: Lynx Africa is terrible and I’m glad I didn’t get one for Christmas this year

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 23

Text: The villains in super hero films are awfully polite. They always confine their invasions to being above one particular city

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say that the invasions that take place are unrealistic and are only shown in this way for plot purposes, as opposed to realism.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 24

Text: Oh my goodness. It’s the first week of the summer holidays and Harrison has found his recorder. Give. Me. Strength.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It is the first week of the summer holiday and My son is playing his recorder and my ears cannot take the sound anymore.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 25

Text: @AsdaServiceTeam imagine your delivery being 2 hours late, and imagine calling up your service team only for them to hang up at 10pm, coincidentally the same time the office closes. But it’s okay, my £3 delivery fee is being refunded though 👊🏻

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's not acceptable for you to just refund my delivery fee.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 26

Text: teams is down what a shame I can’t do my assignments 👉🏽👈🏽

Label: sarcastic

Sarcasm Type: irony

Meaning: Teams is down so I’m happy I can’t do my assignments because of this

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 27

Text: @DuncanEdwards03 @PoliticsForAlI Well I doubt they're trying to smash the doors in to change the regulation of cough medicine.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: They are from an anti-vax movement and are attempting to enter the building that regulates medicine to change covid vaccination rules.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 28

Text: Not at all concerning that a man's just been round to fiddle with the boiler and now he's left the carbon monoxide alarm won't stop beeping

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Very concerning that a man's just been round to fiddle with the boiler and now he's left the carbon monoxide alarm won't stop beeping

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 29

Text: Not telling anyone how I voted in case it doesn't come true #EUref

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I voted leave/remain in the EU Referendum

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 30

Text: just wondering how to get my diss down by 1500 words .. such fun

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: getting my diss down by 1500 words is not fun.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 31

Text: It’s been a blissful 2.5 hours of sleep tonight

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I only got 2.5 hours of sleep last night and it wasn’t enough

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 32

Text: Falling asleep at your laptop is always fun

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate falling asleep at my laptop

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 33

Text: Trying to know all this history tonight is gonna kill me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: trying to know all this history is going to be be a challenge

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 34

Text: love it when Jonny makes me use earphones to watch something on my phone so he can play fifa

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Can’t believe Jonny is making me use headphones to watch something so he can play fifa

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 35

Text: Nice to be compared to a brick wall 😂

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Not happy i have been compared to a brick wall".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 36

Text: @BellularGaming Blizzard will have to make sure it doesn't exceed the recommended fun level of 10%.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Repulsing people would certainly draw attention.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 37

Text: if 2020 was a nose it’d be mine 🐦

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My nose is awful

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 38

Text: Would anyone like to give me some money? #FinDom

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I just watched a documentary about finical domination and would be interested in getting into this line of work, if anyone is interested please let me know - if being genuine. Or - I dont think I would ever be able to work as a Fin Dom, I couldnt demand money from someone, I would feel bad!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 39

Text: Got very excited that my national trust card arrived I am officially a grandma https://t.co/mtkWJCxwom

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am officially a national trust member

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 40

Text: Vaccinated this morning. Not sure it's worked - still committed to Apple and no extra autism detected. Bloody science.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Vaccinated this morning. The vaccine did not contain a Microsoft chip, nor did it make me more autistic than I already am.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 41

Text: ITS COMING HOOOOOME

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It’s coming Rome

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 42

Text: i wish i could tap in to the government bank account🙄🙄🙄

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish I were as rich as politicians are

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 43

Text: 90% of adulthood is just refilling your Brita pitcher.

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: I have to refill my Brita pitcher too often.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 44

Text: I suppose though, we did sign one for the future so, you know, not all gloom and doom...we might be good in 6 years time.

Label: sarcastic

Sarcasm Type: sarcasm, understatement

Meaning: I wish we could have signed a player for the first team.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 45

Text: Where is the Chancellor? Please check the back of your sofas.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: (!) I wonder where the Chancellor is after such an important decision?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 46

Text: i have been informed that, as aroace and agender, i have triple visibility and am now visible from space.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: As someone who is aspec in multiple ways, I enjoy having all parts of my identity being recognised.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 47

Text: going to be running on three hours of sleep at work tonight! so excited!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i’m not ready to go to work after only getting three hours of sleep last night.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 48

Text: @AlexShawESPN @robwishart @GNev2 Does he order 11 at once and drink each one at just over 5 minutes, OR do we have to take into account going to the bar? Either way it’s a disgrace and not what we should be promoting to the kids.

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I don’t think he drank 11 beers every hour

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 49

Text: i’m now reading 4 books at once what could go wrong 🧡

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "i'm reading 4 books at once, let's see if i can actually finish them all"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 50

Text: @ZionWarrior6 I think lunch was ready at the care home, then it was time for nap and then Countdown.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: He's too old?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 51

Text: @Schlippertysch1 @anon_opin Very good. Just need to work on your spelling now 👍

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Excuse me but I think that you have made a spelling error on your last comment there.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 52

Text: July 1st. Half way point of the year. Well I think we can all agree that 2020 has gone swimmingly so far. Can’t wait for part 2. #murderhornets

Label: sarcastic

Sarcasm Type: irony

Meaning: The first half of 2020 is now over, it's been awful so far hasn't it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 53

Text: Got locked out of Twitter for saying it’s embarrassing to be an arsenal fan. That’s not okay, but people can be abusive and racist and nothing?!? Okay! 🤣🙄

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: I don’t appreciate being banned for using the word embarrasing, when others can be racist/homophobic and it’s okay

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 54

Text: I just absolutely LOVE how I've got to work outside for the next 3 days in the heatwave. #sweatingmyballsoff

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate working outside in the heat.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 55

Text: @ThePartridgePod Defrost the freezer with the cast of Hollyoaks. Any of them that wanted an extra fun trip could pop to the recycling centre with some empty pesto jars. Magic.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would actually answer the question - 'Who would you want to spend a bank holiday with?' with an answer that I meant. I would be worried that people would mock me if I was honest though - I don't care when the tweet is clearly a joke.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 56

Text: So, very delayed flight from Bristol to Edinburgh @easyJet, trademark vagueness from staff, with a chronic lack of empathy to boot (despite me travelling with three young children)... now, time to feed our family with £3 vouchers (at airport prices!) #bollocks

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: To buy an airport meal with a £3 voucher is impossible.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 57

Text: we need to normalise having absolutely fried bleach damaged hair. people should talk about this

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am self conscious of my fried, bleach-damaged hair.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 58

Text: Wizkid is the king, ok lol

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Wizkid is not the king lol

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 59

Text: Ah yes, it really is wood-burning stoves in sub-Saharan Africa thats driving the climate crisis 🧠 https://t.co/lShlgWYGOX

Label: sarcastic

Sarcasm Type: irony

Meaning: Wood burning stoves are definitely not an environmental issue that needs to be immediately addressed

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 60

Text: Started watching house of cards, 4 episodes in. Already I can see it was a good choice😄

Label: sarcastic

Sarcasm Type: irony, understatement

Meaning: It was a really good choice! You should all go watch it

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 61

Text: Social Care for the young is basically a bath board and bed rest and your done.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Social care for the young is non existent.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 62

Text: @PONOS_EN Very nice. We're now briefly up to date. Hopefully doesn't take you so long to do the English release of the new pixie after we get 9.10.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am disappointed that it took so long to get to this point where we are up to date.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 63

Text: JUSTICE HAS BEEN DONE.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Justice will never be done

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 64

Text: What a Race ! #sarcastic #WTF1 https://t.co/zRtL5alnoT

Label: sarcastic

Sarcasm Type: irony

Meaning: this was a boring race.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 65

Text: help! i'm being haunted by dead people! (my dissertations)

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate my dissertation

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 66

Text: my neighbors taunting me outside my office window by chilling in their hot tub every remotely warm day whilst I sit here on back-to-back zooms all day every day. the audacity is astonishing.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Very jealous of my neighbors sitting in their hot tub today whilst I am on back to back zoom meetings.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 67

Text: I've been doing physics for 40 minutes I think I deserve a break 😂😂😂😭 I'm never going to get it all done at this rate

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I've been doing physics for 40 minutes, i cant take a break or I'm never going to get it all done at this rate

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 68

Text: Billy Gunn sorta relevant for the first time in years...

Label: sarcastic

Sarcasm Type: sarcasm, understatement

Meaning: Billy Gunn is actually in the spotlight now.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 69

Text: wish i could understand string theory without knowing math..... alas i guess i am too hot for conceptual physics

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could have said that I was too dumb for conceptual physics.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 70

Text: So we actually have to do hot girl summer without 1989 Taylor’s version., I’m sick

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm so sad that 1989 (Taylor's version) won't be released this summer.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 71

Text: 🌶 Spiced Coconut curry 🥥 . A weekend spent with friends brings a week of content... or something like that 😜 . Started the weekend off with this yummy morsel, With was a fusion of miso sesame aubergine 🍆, broccoli… https://t.co/zyWiA0EX4u

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I’m recovering from a hangover

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 72

Text: considering crowd surfing the next time the hallways are too packed

Label: sarcastic

Sarcasm Type: irony

Meaning: The hallways are very crowded lately. I would prefer to take another form of transportation that is more efficient than walking, but none such option exists.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 73

Text: Avoid mass gatherings.. does this mean that I can stay home tomorrow as I work at a school? No I thought not. #schoolclosure

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: I can not avoid miss gatherings as I work in a school.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 74

Text: You know the wolves match is boring when you're talking with your mate about the best way to wire up his new shed!

Label: sarcastic

Sarcasm Type: irony

Meaning: This match isn't too interesting, we are using the time to talk about electrics instead!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 75

Text: What a wonderful time to have your AC go out https://t.co/jqjqG1dGOa

Label: sarcastic

Sarcasm Type: irony

Meaning: Literally the worst possible time to have my AC go out.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 76

Text: @WalesOnline Riveting news.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: What a boring tweet.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 77

Text: My (extended) fam was discussing going on a trip instead of getting presents for Christmas, like okay I’m bout it... Yeah they were talking about doing to the dells. I’ll take my god damn presents thank you very much

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Everyone needs gas-x after having beans.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 78

Text: okay but like the say so song ain’t that bad. I’m unironically jam to it lmao

Label: sarcastic

Sarcasm Type: irony, understatement

Meaning: The say so song was good after the first 5 listens but after that it got annoying

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 79

Text: if you see me crying in the self-service car wash in my rosati’s uniform, no you didn’t ❤️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: No.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 80

Text: Tinnitus is my favourite thing ever I love it. So loud so atmospheric https://t.co/mNJw5GvPzy

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My tinnitus is so annoying

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 81

Text: thanks @SovietWomble for ratting my location out on stream and then embarrassing me 😂 it made my day though https://t.co/3b7Cjql2GO

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It wasn't very nice to rat out my location

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 82

Text: love living in a capitalist society where i look forward to getting a surgery where i’m legit GETTING AN INTERNAL BODY PART REMOVED bc it means i’ll get a few days off from work xoxo

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate that in order to get time off of work, I have to do something drastic like getting surgery

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 83

Text: i love ingesting poison and then wondering why my tummy is rumbling the next morning

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Every time I drink I wake up with an upset stomach

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 84

Text: Beautician and the Beast (1997). Best Timothy Dalton film of all time.

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: I would say what I said above: Beautician and the Beast isn't Timothy Dalton's best film.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 85

Text: @FeeyaCruz Ahahahaha the Feeya I know and love, miss u 😢

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: ‘Oh Feeya, you haven’t changed’’

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 86

Text: absolutely love waking up to the fire alarm at 7 am 😍

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate waking up to the fire alarm at 7 am.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 87

Text: fully vaxxed feeling very girlboss

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: fully vaxxed not feeling very girlboss

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 88

Text: I feel like with the pandemic and all we should now be allowed to publicly shame babies for just like coughing into the open air you know what I mean

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say that “It’s a little gross seeing a baby cough openly in public when adults are not supposed to do the same in this pandemic”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 89

Text: Let me guess, it has to be Charlotte Tilbury makeup. And if by chance you do take it off, use Charlotte Tilbury skincare https://t.co/0c2IfIpy8l

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: She just wants you to use her make-up and skincare.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 90

Text: The typhoon flew over me today absolutely fuming they forgot to bomb me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: the typhoon flew over me today and i didnt get bombed

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 91

Text: love getting assignments at 6:25pm on a Friday!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Please do not give me an assignment right before I clock out because now I have to work overtime

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 92

Text: Raging debate on the importance of an Orlando Magic Summer League Championship. Definitely a notch below 6 if decided by coin flip. https://t.co/LG0VRwkrKO

Label: sarcastic

Sarcasm Type: irony

Meaning: An uninteresting conversation regarding the importance of an Orlando Magic Summer League title.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 93

Text: @rits_meg @freedomsenpai hot loli

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: great art, involve rinako-chan

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 94

Text: Between Mikey cooking and Didi cooking for me I relaxing 😎 cooking?? I don’t know her

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I appreciate that my sister and brother cook for me

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 95

Text: Ah gotta love that Friday morning burnt out feeling 🌄

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate feeling burnt out from work and the never-ending pandemic.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 96

Text: @PFTompkins Her family should definitely not seek mental health guidance. 😬

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: They should seek guidance.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 97

Text: How I flirt with boys Boy: “Hey I saw you from across the room and had to come over” Me: “Wow you’re super observant. Do you have 20/20 vision?”

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I could have said thanks for coming over

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 98

Text: Been trying to get my boyfriends attention. Let’s see how long it takes for him to see this tweet tho.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Sitting next to my boyfriend but he'll notice me on twitter first.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 99

Text: My work email isn’t working so I can just log off for the day right? 🙄

Label: sarcastic

Sarcasm Type: irony

Meaning: I wish I would log off for the day because my email isn't working.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 100

Text: watching olympic womens beach volleyball for the plot

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I watch women's beach volleyball for the hot women.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 101

Text: there’s no better way to wake up than having one dog jump directly on your stomach and knock the wind out of you while the other drop a dead rodent on the end of the bed. 😑

Label: sarcastic

Sarcasm Type: irony

Meaning: "The worst way to wake up is...."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 102

Text: cold ears? take out one AirPod, leave it by the stove, and forget about it for 20 minutes 🤗

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I left my Airpods out by the fire and now my ears are warm.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 103

Text: Do the #Hokies really have to play 5 against 6 tonight? Come on stripes

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Why is the ref helping the other team?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 104

Text: Fool me once shame on you. Fool me twice shame on me. Fool me multiple times I must have become a brexiter. #Brexit

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: by simply stating the foolishness of voting in favour of brexit

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 105

Text: Lucky for 2nd placed Brentford that there's no stand out team like Leeds this year, or they might have no chance of winning the league. #ncfc

Label: sarcastic

Sarcasm Type: sarcasm, understatement

Meaning: Norwich are the standout team this year and therefore Brentford have no chance of winning the league

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 106

Text: how do I get my boyfriend in a maid costume?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: My boyfriend could look okay in a maid costume.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 107

Text: @DonaldJTrumpJr If only he had a press Corp in the house...oh wait! Shut up Jr! Time to get fitted for those lovely orange jumpsuits! If you can't be orange anymore at least you can wear it!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would point out that how can a President be censored if he has his own press Corp right there in the White House

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 108

Text: Wtf is a Justin Herbert

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: "I don't know who Justin Herbert is"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 109

Text: "He's not welcome in a tolerant place like London" @emmadentcoad on the Presidential visit on @BBCRadio4 The irony in that comment... #r4bh

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Donald Trump is not welcome in a place like London.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 110

Text: I love it when drunk, inconsiderate flatmates come back and start climbing on the roof #istillhaveexams #tryingtosleep

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It’s awful that my flat mates have come back drunk and are on the roof when I have an exam tomorrow

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 111

Text: thinking about quitting the path im on to become a college advisor so i can be wrong and do nothing for the rest of my life

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: College advisors are not nearly as helpful as they should be, in fact they are often the opposite.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 112

Text: 2 busy working 2 care

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i don’t care because i’m at work

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 113

Text: Update: they’ve finally closed the campus which means I wasted my day going in and waiting on lectures 🙃 https://t.co/kBTOqNpX3Z

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Although the uni has now closed the campus, I was able to get a lot of work done having to go in

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 114

Text: STOP TREATING MARS LIKE A BACK-UP BOYFRIEND JUST FIX YOUR CURRENT RELATIONSHIP WITH EARTH BECAUSE YOU CAN'T LIVE HERE.

Label: sarcastic

Sarcasm Type: irony

Meaning: 'Focus on fixing Earth before you start experimenting with Mars'

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 115

Text: I just don’t think it’s too much to have a perfect life with absolutely no problems 🤷🏻‍♀️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish there was a way to have a perfect life.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 116

Text: The control button just fell off my laptop. How symbolic for my life.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My control key fell off my laptop and I cannot control my life

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 117

Text: make it illegal to say/write "Dems in disarray" on account of it being stupid as fuck

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Don't say "dems in disarray," because they aren't.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 118

Text: a level tudor history can do one

Label: sarcastic

Sarcasm Type: irony

Meaning: I want my a-level history course to be finished

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 119

Text: Can't wait until I live to be 110 years old and I have people asking me how I've lived for such a long time so that I can make up some hyper-specific secret to longevity that people will inevitably follow

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Although I do not want to live to be 110 years old, I love reading about people's hyper-specific secrets to longevity that other people will inevitably follow

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 120

Text: ugh I have to send an email??? how about I just quit!!!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would rather quit my job than do any of the work I am explicitly paid to do.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 121

Text: Day 3. Luggage arrived, thanks @AirFranceFR. Non random Hungarian underwear. Talk delivered. Science sated. #metaxa http://t.co/6KPjLezQOF

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: After three days of incompetence from Air France my luggage has finally arrived. No thanks to Air France.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 122

Text: went to check out the bios of the (exclusively) hipster dudes that work in a rival boutique goods store and found out they all traveled internationally during the pandemic 🙃🙃🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's really frustrating that all these people traveled internationally

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 123

Text: So in other news I just held the door open for Bam Adebayo &amp; then I fell down the stairs &amp; I think I broke my finger.. ya I'm THAT smooth

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I just fell down the stairs after holding the door open for Bam Adebayo. I really embarrassed myself.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 124

Text: I can't believe today is the last day we can be gay.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Today is the last day of pride month.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 125

Text: did you actually fly on a plane if you didn’t post a picture of the view from your window?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: You don’t need to post a picture from airplane window every time you fly since all pictures from the window are practically the same.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 126

Text: Seeing as Kanye West has a range of clothing with Gap, how about me and you do a collab @FandFclothing

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I think Kanye West and Gap is a terrible collab.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 127

Text: i love jumping on zoom meetings where everyone is talking about their kids &amp; i'm stuffing my face with taco bell

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm sick of listening to my coworkers talk about their kids & want to eat my lunch in peace!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 128

Text: it’s always the girls I don’t even know that wanna talk about me 24/7 :) I love my fans :)

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don’t like people who talk bad about me

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 129

Text: @igreen95 thx for the play by play

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Sounds interesting!"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 130

Text: who thinks me and sam should start a band called 'teeth at midnight' 🦷🌙

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: In an alternate universe me and sam would have been in a band called teeth at midnight

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 131

Text: omg there’s a sheet of ice in front of my school. should I slip and fall?

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: I am in need of money. Therefore, I should sue my college if I fall because they are responsible for not clearing the ice on the ground.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 132

Text: I wish that grilled cheese helped you get that summer bod

Label: sarcastic

Sarcasm Type: irony

Meaning: Grilled cheese doesn't give you a summer bod

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 133

Text: I called out an insta post for fat shaming and am now being told that making fun of someone having no neck is “not making fun of someone’s appearance” !!! The more you know guys!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Instead of saying "the more you know guys!" I would just say "that is not true"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 134

Text: @andy_mansell72 @VicOtley @garry_whu @NiaAnts @davidschneider Finally someone is speaking up for the billionaires.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Billionaires do not need anyone to speak up on their behalf.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 135

Text: @mjborshell @garygilligan Hasn't he opened a few new hospitals? Oh sorry, maybe it was a new first aid box.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Javid hasn't actually opened any new hospitals - he's just announcing that he has when actually he's opening a new facility within an existing hospital

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 136

Text: yeah your girl is fine but does she pass out while giving blood

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Passing out while giving blood is not attractive

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 137

Text: I recovered a repressed memory today of working at @kumandgo in high school 13 years ago &amp; having to answer the phone as “we go all out at Kum &amp; Go, this is Shelby. How can I help you?” And the prank calls that led to. Pretty sure K&amp;G owe me therapy.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't think K&G owes me therapy.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 138

Text: Accidentally made a friend in ASL today. I hate when that happens.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say "Made a friend in ASL today. I love when that happens."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 139

Text: @BoardroomBoy Few links for you. To summarise, wearing face masks seems to be more effective than not. Who'da thunk...

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I would omit the "who'da thunk" part.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 140

Text: Kind of rude of my stomach to still make whale noises after I’ve given it a whole protein bar

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish that my stomach could stop making whale noises after feeding it a protein bar

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 141

Text: Because of #Trump I now don't have to worry about other countries making fun of me for being fat! 🍩🍫🍰🍕 #Thankstotrump #America

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don’t like my country being the “fat” country.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 142

Text: Overthinking everything in life really takes a toll on you

Label: sarcastic

Sarcasm Type: irony

Meaning: There is a contrast between the word "overthinking" and how everything in life really does not take a toll on you.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 143

Text: Man I just love it when I'm forced to pitch two games back to back bc our other pitcher didn't show up

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Pitching two games back to back is exhausting.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 144

Text: I’ve seen a lot of people on local Facebook groups asking AirBnB owners if they have any availability recently. If only there was a website you could use to find out if an AirBnB was available 🤔

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: There is a website you could use to check if the airbnb is available

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 145

Text: @SuspendThePres But what were the ratings?? (Replied to his Tweet with the same thing.)

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Ratings should not matter.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 146

Text: dont you love it when youre just chilling in your room and then theres a spider and you kill it but when you kill it you spill soda all over your keyboard yeah me too

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: dont you hate it when youre just chilling in your room and then theres a spider and you kill it but when you kill it you spill soda all over your keyboard yeah me too

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 147

Text: @MollyJongFast I think it should be allowed for customer service workers to squirt water into their face like how they do sometimes to train pets

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The customer service worker sprayed customers with water like one does to train pets.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 148

Text: Taxes are just the best and I cannot wait to pay more 😇🥰🥺

Label: sarcastic

Sarcasm Type: irony, satire

Meaning: I dislike paying taxes.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 149

Text: Goodness my parents are actually watching something on Apple TV+, brilliant, yet another streaming service! 😪

Label: sarcastic

Sarcasm Type: irony

Meaning: Annoying that we have to use another streaming service to watch some TV

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 150

Text: alright I’m ready for some march madness🏀🔥

Label: sarcastic

Sarcasm Type: irony

Meaning: I was ready for some march madness, then COVID happened

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 151

Text: I still can’t believe England won the World Cup

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I still can’t get over the fact England did not win the World Cup

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 152

Text: dont u just love when u get ready for a cancelled date two hours early . . . yeah i wasnt excited or anything

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: My date got cancelled, and I got ready for nothing.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 153

Text: wouldn’t it be cool if i could spontaneously combust

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I'm frustrated and I don't want to deal with things right now.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 154

Text: Efy is great

Label: sarcastic

Sarcasm Type: irony

Meaning: EFY is a time for white, religious kids to make weird friends and mess around while not doing anything productive.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 155

Text: @sonofsama1 @Santandave1 you’re trash

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: You’re terrible

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 156

Text: cold queso is so much better than warm queso https://t.co/5TaMe4aSO6

Label: sarcastic

Sarcasm Type: irony

Meaning: Cold queso is gross and warm queso is so much better.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 157

Text: Wow it's almost as if it's their literal job to have a lot of knowledge about a wide array of subjects.. Funny that https://t.co/NGi02vXxnK

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "It's literally their job to have a lot of knowledge on a wide array of subjects"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 158

Text: It’s really very selfish of Silverstone to be saying the 2022 Grand Prix is 1/7-3/7 cause my holiday year starts on 1/7 and I would have to use a day of this years holiday allowance to go. I should have been consulted really 😵‍💫😵‍💫😵‍💫

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It’s really annoying I have to use one day of my holiday allowance this year to attend the Grand Prix.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 159

Text: "are you experiencing suicidal or homicidal ideation?" "only while trying to talk to a human when I call @Walgreens pharmacy"

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate the Walgreens robot

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 160

Text: Just getting some WD40 on my letter box to help the poor postman with his delivery today #valentinesday2021 #WD40

Label: sarcastic

Sarcasm Type: irony

Meaning: Fed up of seeing forced romance, don't be told when to do something nice for a person you love.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 161

Text: I’m sorry, but if you message me on Instagram wanting me to help you sell your fit tea and wraps, I’m leaving you on read. 🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I will not answer you if you message me about fit teas or wraps. I’m leaving you on read. I’m not sorry about it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 162

Text: wow i love only ever buying gray and striped shirts

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish I didn't just buy gray and striped shirts.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 163

Text: no more instagram. we must all return to scrapbooks.

Label: sarcastic

Sarcasm Type: irony

Meaning: I would rather make a scrapbook than use instagram.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 164

Text: Thank you twitter for deciding to completely reset your list of the "suggested topics to follow" I've clicked to ignore (all of them), so now I'm back to seeing hundreds of them, every time. Really appreciate you doing that.

Label: sarcastic

Sarcasm Type: irony

Meaning: Twitter has reset the "topics you might be interested in". It's awful - all the topics I've clicked "ignore" on are coming back to the "topics..." section when I scroll any profile or TL, and it's so become a very frustrating experience.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 165

Text: Thank god I just accidentally snapped a rando guy from high school ‘yas queen’ with acne cream all over my face

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The tweet could be, "oh my goodness I just accidentally snapped a rando guy from high school ‘yas queen’ with acne cream all over my face" to make it not sarcastic.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 166

Text: I hurt my foot like 3 days ago, I have no idea how, but it hurts to put pressure on it. Love that for me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I really do not love hurting my foot, it's really painful!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 167

Text: me: trying to sleep slightly earlier than usual bc I feel like shit my friend, texting the group chat 13 separate times at nearly 4am: hello I don’t think so! how abt I tell u abt how bad things are going instead :)

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I might say “I am so annoyed that my roommate won’t stop venting to me when I’m trying to sleep, I already don’t feel good and was trying to sleep Early for Self Care and having them bombard me with their problems at 4am is really putting a damper on things”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 168

Text: Thank you to my apartment complex for consistently cutting the grass at 8 am every Thursday for ~5 hours. It’s definitely not super obnoxious or bothersome ☺️☺️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: @ my apartment complex: please pick a time later in the day to mow the lawn. 8 am = cranky residents.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 169

Text: 5:30 banshee-like kitten zoomies are definitely my all-time favorite alarm clock, and the sound of jewelry boxes flipping over and burnouts on the wood floor make for the calmest, most enjoyable start to any workday.

Label: sarcastic

Sarcasm Type: irony

Meaning: "I can't stand when the kittens have so much energy at the crack of dawn that I get woken up by a loud, noisy mess they've made"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 170

Text: Sometimes I feel like all this effort is just like sticking diamond encrusted alloys on a knackered Corsa. I mean, shit is what it is at the end of the day.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Therapy can only do so much.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 171

Text: a single man directed by tom ford simultaneously resurrected me from death only to brutally murder me once more.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Tom Ford, as a movie director, makes me feel big feelings and that's impressive to me.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 172

Text: Hey Siri, how do I stop simping?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I don't like that I put too much effort into someone who may not like me back.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 173

Text: we love mixed signals🙄

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate mixed signals.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 174

Text: Hey does anyone know of any organizations that have massive stockpiles of money that could be super useful to the world during a public crisis?????

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: In the follow up tweets, I said this: "I would just like everyone reading this tweet to remember that we live in a capitalistic society and that 90% of your favorite organizations have huge stockpiles built up that would be super helpful in a public crisis. And many don’t pay taxes. If you think of a person or company or organization with the resources to share their excessive wealth... maybe write them emails and suggest they do so."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 175

Text: Wow Bdubs can bench press 150 kilometers

Label: sarcastic

Sarcasm Type: irony

Meaning: Bdubs can't bench press 150 kilometers

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 176

Text: Nothing screams “I’m a glamorous cosmopolitan woman” like following your dog down the street in the midst of winter, saying “go potty! Go POTTY!” over and over again.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Shouting "go potty" at my dog is not at all glamorous or cosmopolitan.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 177

Text: Heard a rumor that Baja Blast is coming to stores and regardless if anything else I hope for in life falls through, at least I'll have this.

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I've heard that Baja Blast may be sold in stores and I would enjoy that because I think the drink is good.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 178

Text: @KhoaVuUmn Reviewer 2: this is a very weak paper that fails proof of concept. Stating a cat bed is also a wizard's hat is totally wrong and your data cannot support this

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "this reminds me of the reviewer 2 trope"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 179

Text: A wrong impression is once again my specialty

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Unfortunately I made the wrong impressions again.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 180

Text: if trees would simply stop producing flammable leaves climate change would not be an issue

Label: sarcastic

Sarcasm Type: irony

Meaning: putting the blame on trees for causing fires is stupid

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 181

Text: haven’t written in months cuz there are no male teachers to impress 😣

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I haven't written in a while and that sucks

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 182

Text: hey quick question is it fall or spring???

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: Why is it so frickin warm in November someone lmk

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 183

Text: when the toilet seat is warmed up for you&gt;&gt;&gt;

Label: sarcastic

Sarcasm Type: irony

Meaning: Ew this toilet seat is warmed up.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 184

Text: @PlayStationUK Nice

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: These aren't very good games

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 185

Text: me and noah forgot that today is our anniversary. if that isn’t couple goals then idk what is 😌

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Me and Noah forgot our anniversary. That is not “couple goals”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 186

Text: I can’t wait to hear more about the life of an upper middle class East Asian American whose only personality trait is drinking boba tea https://t.co/SapbXLd0r2

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I am tired of hearing stories about upper-middle-class East Asians who are one-dimensional caricatures of Asian American culture. Let's hear more from underrepresented groups or get more realistic stories".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 187

Text: Hey what's the weather like today? Am I going to need an umbrella?

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: I'm joining in with the rest of Twitter and can't believe how much rain there is

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 188

Text: trying to figure out how to use notion for my anime list. I think i’m dying

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I'm so confused"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 189

Text: Do you think anyone on Bachelor in Paradise has seen Oscar winner Parasite?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I do not think anyone on Bachelor in Paradise has seen Parasite.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 190

Text: "your pronouns are what's in your pants" ok. juicy/dumper

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Your pronouns are not what's in your pants

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 191

Text: It’s so amazing how people forget you exist until they want something from you :,)

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It is terrible how people forget you exist until they want something from you.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 192

Text: 2 things I love: 1. Being woken up by construction work an hour before my alarm. 2. Sarcasm.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I really don't like being woken up by construction workers an hour before my alarm is meant to go off.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 193

Text: How bout you dont use a gazillion filters on your pictures

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: You edit your pictures so much it doesn’t look like you

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 194

Text: finished the queen's gambit, i loved a look into the 1960s in the american south with no racism just vibes

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: it's odd that the queen's gambit is set in the american south in the 1960s, yet never discusses racism

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 195

Text: Wow it’s almost like we don’t nap every single day at the exact same time wow how dare I try to do the thing we do every single day!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: We nap at the same time every day

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 196

Text: @brruhia Nah bruh you just drinking it upside down 😂

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would have said this as an answer to a different question in order for it not to be sarcastic.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 197

Text: @raerenyse Easily one of the worst and most damaging takes for both trans AND cis women I have seen thus far. Congrats on reaching new levels of awful lmao

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Easily one of the worst and most damaging takes for both trans AND cis women I have seen thus far. You have surprised me by reaching new depths of depravity via tweeting this.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 198

Text: @PoliticalOrgy I thing you might be on to somethink!🙄

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't think I could.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 199

Text: Here comes the final of the UK #DailyBriefing - who will win, Johnson or Covid?

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: How will the UK government be changing the Coronavirus restrictions in tonight's briefing?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 200

Text: "You're not a normal white girl" lol ok

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am a normal white woman

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 201

Text: Great time for sim and I to have our weekly life update.... 🌛🌜🐨 (closest thing to an owl) 💤💤💤💤💤😴

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: So late for Sim and I to have our weekly life update!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 202

Text: I love when you go to shop for plus size clothing and it's always just shoved under women's and it doesn't have any subcategories so u just have to wade thru everything like a pig being thrown slop

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate how difficult it is to shop for plus size clothes.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 203

Text: @richardosman @GMB @susannareid100 @piersmorgan You've a book out? I hadn't realised. Yes, you've already read this 8763 times this week, but hey.

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I'm interested that you have a book out.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 204

Text: Hahahah @LibertyU is shutting down the entire campus for quarantine!! Couldn’t happen to a nicer group of Covid deniers! #CovidIsNotOver #karmaisabitch #Covid_19

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It seems like liberty university has been chromatically shut down due to their inability to abide by social distancing or mask rules

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 205

Text: Brother's off on a night out and I've gone to bed cos I feel exhausted and sick.... excellent 👍🏻

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It’s not fair how I’m unwell yet my brother can head out on a night out

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 206

Text: “The App Store [is]... an economic miracle” 🙄 but Apple magic not working today at #AntiTrustHearings #Apple stifles innovation that is the lifeblood of our economy. -Lucy McBath speaking some truth today #HouseJudiciary https://t.co/2swhC9daBM

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Apple which arguably has a monopoly - in its users only being able to buy apps via its app store- was today described by Tim Cook as "...an economic miracle". It was tough to watch as Apple's CEO, Tim Cook, struggled in the hearing.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 207

Text: I love how they blur out Tristan’s face in this season of the kardashians LMAO like hmmmm I wonder who that mysterious man is

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Instead of "I wonder who this man is" its "everyone knows who this man is"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 208

Text: In sunny spain at the moment!!! Hows it all in england?

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: its sunny in spain, sorry its raining back at home.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 209

Text: my super power is always biting into the sour cream side of the burrito no matter what

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I cannot stand that every time I bite a burrito it's a mouthful of sour cream.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 210

Text: if you display your pop funkos in the box then you’re a tory

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don’t like when people display pop funkos in their boxes

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 211

Text: #HappyBirthdayKeanuReeves Keanu Reeves is so wholesome ☺️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Keanu Reeves is a pretty great guy.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 212

Text: Don’t worry, 20 something people who follow me here, I brushed my hair for the first time in a week today. I know, impressive.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I brushed my hair today, how easy.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 213

Text: @kmflett And with a plentiful supply of rhubarb.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It is good that Geoff likes rhubarb.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 214

Text: Hearing Kendrick Perkins refer to Alec Burks as Alecs Burk like he’s attorneys general &gt;&gt;&gt;&gt;

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say I ahte him

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 215

Text: Wait didn’t covid go away?? It’s after November third so it definitely should be gone now...wait...I’m confused...121,000 cases in a day? You’re telling me THE WHOLE WORLD didn’t fake a pandemic for the US election? No way...

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: The pandemic is still very much real and has absolutely nothing to do with American election cycles. It is still happening. Please take it seriously.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 216

Text: We really need to remind people that universal healthcare means never needing to sit through another annual explanation of benefits meeting

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Universal healthcare saves a lot of time and makes life easier

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 217

Text: wow. i left on time today and the airport connector is all the way backed up. love that

Label: sarcastic

Sarcasm Type: irony

Meaning: I'm so mad that I'm stuck in traffic and late to school, especially because I left early.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 218

Text: maybe i am a cyber bully

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Telling someone when they’re wrong and being ignorant doesnt make me a cyber bully.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 219

Text: "@elliekonsker: FLORIDA YOU LITERALLY HAVE ONE JOB"

Label: sarcastic

Sarcasm Type: irony

Meaning: I don't like when it's cold in florida

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 220

Text: Andrews really trying to explain to me that football and rupauls drag race aren’t the same thing when it in fact is the same thing.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Football and RuPual's Drag Race are wildly different shows.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 221

Text: day 5 of people being mad about ellen sitting by gw bush is when we'll finally get to the bottom of this

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: People are wasting everyone's time by talking about Ellen sitting with George W Bush like it's an important and shameful event.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 222

Text: Cool guy in a big truck honked really long at the garbage truck because it slowed down to turn; I felt he wanted everyone to know how cool he is, so I decided to tweet about it on his behalf.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Some jerk just honked at a garbage truck because it had to slow down to turn. It was obnoxious

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 223

Text: NOT OLIVIA RODRIGO TRAITOR IN THE BACKGROUND #LoveIsland

Label: sarcastic

Sarcasm Type: irony

Meaning: traitor by olivia rodrigo in the background ?? YES

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 224

Text: i’ve never had protected sex

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I always use protection when having sex

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 225

Text: Duodenum, Jejunum, and Ilium would be cute names for triplets, don’t @ me

Label: sarcastic

Sarcasm Type: irony

Meaning: Duodenum, Jejunum, and Ilium would not be cute names for triplets because they are the names of the three parts of the small intestine.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 226

Text: Only yelled at one person while biking home this evening. Improvement!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I had to yell at someone while biking home today.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 227

Text: .@taylorswift13 is 100% going to post another photo with 5 holes in a fence 5 days before Lover is released, isn’t she?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Taylor swift is so extra.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 228

Text: the fact that “breaking: school shootings preventable” was an actual headline on nbc tonight is actually laughable

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: the fact that "breaking:school shootings preventable" was an actual headline tonight is a sad commentary on our country

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 229

Text: I love when I start choking on my water in my 8 person class

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It was embarrassing when I choked on water in front of my class.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 230

Text: Whoop diddy scoop poop

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would’ve just tweeted that I hated Kanye’s new song.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 231

Text: @WilliamShatner Mr Shatner whilst you were sleeping you asked me to join Facebook messenger and then after a polite conversation you then offered me gold necklaces and a singed (sic) tee-shirt - you made my Friday night sir... just awaiting your instructions so I can wire the money...

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: I would have said it ruined my Friday when I realised that I had been fooled by a Shatner impersonator.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 232

Text: is it illegal to discriminate against someone on the basis that they have a joker tattoo

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: This guy has a joker tattoo and that's off-putting to me.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 233

Text: it’s been 20 hours and i want another chai latte with pumpkin cold foam i can’t afford this!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “i am going to go broke if i keep buying iced chai lattes”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 234

Text: It would be a real shame if people shared this around and filled it with fake info. People should definitely not do that 😉 https://t.co/Px7dYqjh3I

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "People should share this and fill it out with fake info."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 235

Text: Well done Henri, cost us the win #nffc

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Terrible Henri, you cost us the win.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 236

Text: I love not being pregnant so much it’s my fave thing about myself

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Im happy not having children.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 237

Text: @ray_harren @tkinsonn buy really rare pokemon card

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Buy something that is of value, either stocks or other long-term investments

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 238

Text: you like ketchup but not tomatoes??? grow up

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It seems childish to enjoy ketchup but not tomatoes

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 239

Text: Big day in the Mumford house #sports day

Label: sarcastic

Sarcasm Type: irony

Meaning: Such a shame there’s no sports day.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 240

Text: @ShareZone5 @StockpickB You are a right bundle of laughs to take to the pictures Draft!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say he’s being miserable and not that his a bundle of laughs.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 241

Text: “If I could have changed anything about my childhood I would have never watched spongebob” -no one

Label: sarcastic

Sarcasm Type: irony

Meaning: "I don't think anyone regrets watching Spongebob as a child"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 242

Text: #bbcqt It sure would be nice if Ms May decided to answer a question, rather than dance readily around it.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Theresa May just needs to answer the question.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 243

Text: Does anyone not know Prince Harry got engaged? I don’t think there’s been enough in the news about it.

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I think we've all heard enough about Harry and Meghan's engagement.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 244

Text: @sadgirlkali Make your husband agree to let you die first. FUN date topic for discussion

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Talking about death is not a fun topic for date night.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 245

Text: im ollie im 5'8 and i think my 5'7 boyfriend is short

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I think people below the height of 5'8 is short.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 246

Text: Tonight @ dinner I sat by &amp; chatted w/ the former chancellor of Ole Miss, a former Miss MS, &amp; the owner of the Miss America pageant Casual.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Tonight @ dinner I sat by & chatted w/ the former chancellor of Ole Miss, a former Miss MS, & the owner of the Miss America pageant I'm freaking out this was so cool!!!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 247

Text: wow this growth spurt is really taking longer than i thought haha

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am short.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 248

Text: Quarantine Day 256: Dear Ancient Greeks, re: the blanket-wearing—I get it. #QuarantineLife

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Honestly, the value of comfortable clothing cannot be understated."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 249

Text: my bf took my off his lock screen which obvi means he’s cheating on me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My boyfriend is cheating on me

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 250

Text: Gonna go cry now some no face told me to lose weight x

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Fuck the person who told me to lose weight

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 251

Text: 'Margaret Thatcher' is trending... has 2016 taken another one?

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Non-sarcastically I'd probably say "Oh, out of curiousity, what's the reason for Ms. Thatcher trending?"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 252

Text: Hear me out... The lyrics in "coney island" should've been "lost again with no surprises, disappointments close your EYESES" Fixed it for you @taylorswift13 😉 #evermorealbum @taylornation13

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The Lyrics to Coney Island should not have been "Lost again with no surprises Disappointments close your eyes".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 253

Text: At least half of my days are still bad days and let me tell you, i've never once killed 8 people because of it. A true miracle apparently

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I've been depressed for a long time and I never managed to kill anyone. It isn't hard not to do.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 254

Text: Of course the moment I front the system is in utter chaos 🥴

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm not happy about me fronting during chaos.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 255

Text: Day 38 of quarantine is an interesting time to get a new drum kit, neighbor

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Getting a drum kit this late into quarantine is weird and off putting.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 256

Text: Hate this site [CHIRPBIRDICON]

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I love this site

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 257

Text: did you know there is a direct correlation with how cool someone is and how high they cuff their pants?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Cuffing your pants too high is embarrassing and it does not make you cool

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 258

Text: @McDonaldsUK Would love a cheeky McDonald’s breakfast before a busy day at work would set the day off on the right foot ! 💓 #FancyAMcDonalds

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I would love a McDonalds breakfast this morning!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 259

Text: I swear this triller event is run by teenagers

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The Triller boxing event seems to be run very poorly by inexperienced people

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 260

Text: What kind of sins have y’all been committing for God to punish us with this kinda weather...

Label: sarcastic

Sarcasm Type: irony

Meaning: God are you punishing us by creating such bad weather?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 261

Text: I’m really looking forward to not hugging my friends and family through choice rather than by law.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would like to continue social distancing and not hugging people ever

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 262

Text: Men will literally fake an injury on the football field instead of going to therapy

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Men should go to therapy!!!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 263

Text: I don't think Republicans have any self awareness or any idea of how the world works... Nice try though.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I really think that older Republicans are lacking in self-awareness in the modern-day. They had a complete misstep and just ended up bullying a teenager."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 264

Text: There is not enough people here #ivoryrooms

Label: sarcastic

Sarcasm Type: sarcasm, understatement

Meaning: Ivory rooms is not busy tonight

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 265

Text: I love online shopping because if I am physically in a store and an employee even looks at me I will immediately leave.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I like online shopping because I am shy.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 266

Text: WHO LET THE LAUNDRY PILE UP 5 BASKETS. Goodness.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Why did I let the laundry pile up 5 baskets?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 267

Text: Boehner not clapping for gender pay equality. COOL.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Boehner sucks for not clapping for gender pay equality.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 268

Text: Drop in Center to let people get the 1st or 2nd Vaccine open today . I went thinking I was able to get my 2nd one . Wait in the que 30 mins .sits down arm ready to get ! Sorry your 12hrs to early !!! We cannot vacinate you till 56 days !!! @NicolaSturgeon #Seriously

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I was to undertake my 2 covid vaccination but unfortunately I turned up 12 hrs to early and could be completed until after 56 days

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 269

Text: "I'm concerned about the environmental impact of my contact lenses," says the occasional daily wearer, throwing their Starbucks cup in the test room bin.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: You can't care about the environment only when it's convenient to you.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 270

Text: Shout out James Boswell #unibowl

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: James Boswell is a waste man.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 271

Text: @ThomasCabaret84 @MicrobiomDigest @raoult_didier Surely you’re not suggesting that their own thorough investigation of their own suspected &lt;fraud&gt; (which found no evidence for said &lt;fraud&gt;) was carried out with anything but the very highest levels of integrity? Seems completely legit to me…

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could have said “this investigation was not legitimately carried out.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 272

Text: @xNemoooo @McDonaldsUK @tasshx Say swear you didn’t down all bev’s at Acapulco’s straight after?? 😘

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Didn't you have all the beverages at Acapulco's last night?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 273

Text: I got called ugly on Twitter by an uneducated teen who refuses to show his face:( I’m gonna cry myself to sleep😭 I’m in gut wrenching pain!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I was unaffected by an interaction with someone on twitter

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 274

Text: @benshapiro it’s true, every time my little cousins put on their masks they choke to death and have to be revived. it’s very stressful for us.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: No.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 275

Text: Just dislocated my fucking knee again while out on a walk 🙃🙃🙃 FAB

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I've dislocated my knee again, ouch!!!"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 276

Text: Headaches that last all day nonstop🥰😍

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate headaches and I have one.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 277

Text: Pissed off at @TMobile_USA and just want out of my contract, but I'm sure that would just be way too easy, ugh :(

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It would be nice if T-Mobile could assist me in getting out of my contract

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 278

Text: Football is turning into an anatomy lesson. COOL

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am frustrated with the new football graphics because I am uninterested in player injuries and it reminds me of anatomy class.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 279

Text: @BIGRXD12 ah yes, people with eating disorders, famous for easily being able to not worry about their weight

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It may be difficult for someone with an eating disorder to avoid worrying about their weight.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 280

Text: As if I didn't know this anyway! I'm an Owl according to the #BBCBodyClock quiz – what are you? https://t.co/vM07K82CTg

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I already knew that I am a night-owl.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 281

Text: i would kill a man for a forehead kiss rn

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: "I'd love a forehead kiss rn"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 282

Text: Mental shoot out ends. Silent pause. Sirens start 🚨 Always so perfectly timed 🚔🚓👍🏽 #LineOfDuty #LineofDuty6 #LOD6 #LOD

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The sirens always start just as the gunfire finishes

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 283

Text: Love being called the devil for taking away someone’s phone at summer school🤗🤗🤗

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “It was not enjoyable to be called the devil for taking someone’s phone”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 284

Text: everyone pls stop shooting fireworks my dog is scared :(

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish people would stop shooting fireworks because it scares my dog.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 285

Text: I love days when Rob works short call and is only at the hospital for *checks watch* 13 hours.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate when Rob works short call and is still at the hospital for 13+ hours.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 286

Text: @tedcruz @Dream worst timeline

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: A US Senator should not be tweeting about Minecraft Youtubers.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 287

Text: @BBCAMERICA Thanks for disrupting your narrative continuity with commercial break previews. #SpoilerAlert

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish @BBCAMERICA would stop spoiling shows as they air with scenes from what I'm already watching.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 288

Text: i love how i literally just finished watching the fifth hp film and then turned to my mum and said "love a good bit of character death on a sunday :)" the dsmp lore has utterly ruined my attachment to characters and how i see stories now. i am a broken woman.

Label: sarcastic

Sarcasm Type: irony

Meaning: i love how i literally just finished watching the fifth hp film and then turned to my mum and said "this bit of character death on a sunday has made me sad" the dsmp lore has utterly ruined my attachment to characters and how i see stories now. i am a broken woman.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 289

Text: i went outside today and suddenly my depression is cured

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My depression will not be cured in a day

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 290

Text: Can’t wait to be back at uni so I can order more shoes and clothes without my mum telling me off x

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: When I go to uni Im going to spend more

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 291

Text: love when the train stops in philly and everybody boards and of a sudden it smells like a ham sandwich

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i'm disappointed but not surprised that my train stopped in philly and everybody got on and suddenly it smelled like ham sandwich

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 292

Text: Thanks @Tesco for not informing me that my click and collect order had been cancelled when my account says it's ready to collect my partner has had to travel unnecessarily to Stafford and we still don't have our shopping, good diet I guess having to wait for my 26th delivery slot https://t.co/xq9oXEkw8o

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Tesco have cancelled my order with no warning. please could i have an explanation and compensation for this.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 293

Text: My dream is to be left alone.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I simply do not want to be bothered by annoying people ever again.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 294

Text: @lora__ SHOCKED. How am I supposed to tell the kids they're not going to Disneyland on June 21st after all? It's already been cancelled 36 times! https://t.co/SV8gpPn6yw

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: These people were aware of the risks when they booked these trips so they should not be surprised when they get cancelled.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 295

Text: @BorisJohnson @MattHancock Oh really?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Investment has been lacking for years, why should the public believe you now?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 296

Text: we happy!!!!!!!!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am unhappy

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 297

Text: first day of work, and i’ve already cried on the job 👍

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i would say the same thing and use a sad emoji like 😭,😢, or 😥

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 298

Text: The fact I nearly froze on my way to work this morning is definitely a sign it's not summer anymore #freezing

Label: sarcastic

Sarcasm Type: irony

Meaning: You wouldnt think it was summer anymore!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 299

Text: Damn, imagine being vaxxed and then getting a cold and then losing your taste and smell. Oh wait.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: To make it non-sarcastic I could have said, "I hate having a cold and then losing my taste and smell."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 300

Text: Is this first Cybex isokinetic dynamometer? @DrAndrewBateman #PRS2021

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: That’s an interesting machine. Is it very old?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 301

Text: how you gonna ask me how i’m doing “on this fine labor day” while you’re off, as I’m ringing you out, on labor day. how do you think i am 💀

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: “I’m working on Labor Day, I am obviously not having a great day as I could be off like you are but I’m not.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 302

Text: apparently it’s national siblings day? idgaf 💀

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Happy national siblings day

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 303

Text: Worked out 2 days in a row. I am quite literally the epitome of health and fitness

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i've worked out for two days in a row, i feel healthy.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 304

Text: yes i have little interest in doing things that applies to me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am depressed and anxious

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 305

Text: If you ever wanted to know what it feels like to have dyslexia I would recommend the book House of Leaves.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: This book makes me feel like I don't really know how to read.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 306

Text: @DanielIngolfur @The_Timbrodini @ViQueen55 @tedcruz I know, right? He even wanted poor people to be healthy, because he was basically a fucking communist. What a hippie.

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Jesus wanted everyone to be cared for, because he was all about loving and caring for your fellow man.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 307

Text: @DylanPetit17 @jaredj5 Let's listen to Dylan Petit over actually doctors, biologists and epidemiologists. 🙄

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Let's listen to doctors instead of this random guy online.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 308

Text: Don't let people walk all over you. Or breathe on you. Either one.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say " It's difficult but do your best to not let people walk all over you. Or breathe on you."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 309

Text: Kepa had a great game

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Kepa was sh*t

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 310

Text: I am starting off my day by watching a Dragons Den special on Deborah Meaden and eating a Pot Noodle. My life is perfect.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am starting off my day by watching a Dragons Den special on Deborah Meaden and eating a Pot Noodle. My life is a sham. Send help.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 311

Text: @Moffstovoi Well done! With the better coaching now available, can we expect a decent wee victory tomorrow? 😅

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Well done, great achievement. Can only be mutually beneficial.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 312

Text: @stockwa16053563 @PeterGWall @michael_saylor Michael Saylor is efficient in his line of questioning. Feels like more an interrogation 😂⭕️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: His questions are too basic the interview it not worth watching.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 313

Text: I'd like to thank middle aged men watching the Olympics for solving the mental health crisis. Getting someone to shout "get some perspective" at every athlete struggling with anxiety will definitely solve their problem.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's annoying that middle aged men are declaring people with mental health issues need to find some perspective; that's insensitive and unhelpful.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 314

Text: does ur dad hate you for no reason or are you normal?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I feel like my dad hates me

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 315

Text: I miss walking up 3 flights of stairs for class and having to catch my breath in the bathroom 😩

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate walking up 3 flights of stairs and catching my breath in the bathroom.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 316

Text: this is my 3rd time taking a biology course and it’s so EASY wow i love biology so much i’m so glad i’m so good at this subject.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "This is my 3rd time taking the same biology course, I am not good at this subject at all"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 317

Text: Hot dog eating contest as a form of assisted suicide

Label: sarcastic

Sarcasm Type: irony

Meaning: You shouldn't have a hot dog eating contest as a form of assisted suicide.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 318

Text: Being 20 years old and going to concerts with my mom means I can scream all the no-no lyrics bc iM aN aDuLt

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I scream lyrics at concerts with my mom.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 319

Text: it'd be nice if missguided actually had stock for once🙂🙂🙂

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: There is never any stock at misguided.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 320

Text: first game not starting when it's supposed to? a UCF tradition

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: UCF football games get delayed or cancelled.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 321

Text: Having a bad week but what else is new!! At least I finally got paid 💕😭

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I had another bad day which is becoming common for me at the moment.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 322

Text: im about to just walk into a place and start working then and there and they'll have no choice but to hire me on the spot

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish someone would hire me so I don't have to go through hoops and hurdles.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 323

Text: just stuck my entire hand in a hot oven without thinking about the consequences. self preservation is clearly my strong suit

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Self preservation isnt my strong suit

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 324

Text: Turnover is the best band to cry to/drive to/daydream to/fall asleep to/ reminisce to/die to

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say, turnover is the best band to do anything to. The music just encapsulates so many feelings all at once!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 325

Text: Congratulations to Trump on his second impeachment. It’s a tremendous achievement borne of hard work, focus and dedication. Record breaking. Historic. Bigly. #ImpeachmentDay #TrumpImpeachment2

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: You're a disgrace, President Trump, and you deserve to go to prison.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 326

Text: yeah i enjoy some oregano on a nice pasta dinner (dumps oregano on mac n cheese)

Label: sarcastic

Sarcasm Type: irony

Meaning: I like to put oregano on my mac and cheese

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 327

Text: everytime i swipe through bumble when i’m bored i just get sad that no one has the same complex interests as me….rude 😤🙄 /j

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Everytime i swipe through bumble when i’m bored i just get sad that no one has the same complex interests as me.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 328

Text: Sitting next to the world's loudest mouth-breather on the first day of class did a really good job of demystifying grad school for me today

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I was very annoyed today in my first class of the year because I sat next to someone who had very loud breaths.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 329

Text: every date I go on I get a little scared will be phone swap

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am not afraid that I will be on the show phone swap while I go on a for date

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 330

Text: Nothing warms my heart more than seeing everybody come together and attack Westside’s administration ❤️ #WycoPride #YeeYee

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Attacking wyco is dumb

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 331

Text: Blatantly obvious that Lionel Messi is now set for a move to Leeds. The Newell’s old boys network.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Clearly Messi won't be signing for Leeds United but it would be interesting for him to play for Bielsa.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 332

Text: Can’t wait to get home take a big ass antihistamine and roll in some topical steroids. Damn it, skin! What did I ever do to you?!?!

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: My allergies are really acting up and I need to take some antihistamines and use ointment.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 333

Text: “tit for tat, butter for fat, you kill my dog, i eat your cat” is a liberian proverb for “an eye for an eye”. my ancestors were spittin’

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My ancestors spoke about a lot of true things

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 334

Text: @Chris_Ransom @CityView1904 @Uzzell01 @BBCSport Aware she was not a tennis player when she left Canada at 2 yrs old?? aware she did not pick up a tennis racket until 6 years old??.aware last12 years trained at the same tennis club in Bromley Kent England??the girl is British no haters or doubters will take that away from her

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I could tell the person to go read up on some facts it may help there IQ

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 335

Text: was not aware that Crocs were appropriate business casual attire.

Label: sarcastic

Sarcasm Type: irony

Meaning: I do not think that Crocs are appropriate professional footwear.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 336

Text: On a scale from 1 to 10 how deeply was your childhood influenced by the Hannah Montana 2: Meet Miley Cyrus double album? This is for research purposes.

Label: sarcastic

Sarcasm Type: irony

Meaning: Who else remembers the Hannah Montana 2: Meet Miley Cyrus double album?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 337

Text: Oh? You're a real anime fan? Name all the Boku no Pico characters, I'll wait.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Real fans don't have to prove themselves to anyone by listing off arbitrary facts.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 338

Text: @kidcuisine98 Based confidence and believing in proper eye contact-pilled!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say "Yeah, I never get why so people have the issue of maintaining eye contact, it's relatively easy for me to do."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 339

Text: Replace Pelosi #Nancy

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: He should not have been elected president and donald trump won the presidency.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 340

Text: oh sure, the mic’d up pitcher at the MLB all-star game can say “god dammit” but when my 13 year old softball player says it she gets a “language warning” 😂

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: MLB players can swear on TV and not get in trouble, but when a youth softball player does the same thing, she will get in trouble.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 341

Text: @SrutisJay one of them smonks weed so it's super worth it /s

Label: sarcastic

Sarcasm Type: irony

Meaning: None of those designs are really worth the money.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 342

Text: @Dancruz07 Sureeeeeee you do

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could've replied "You do not despise me, you're my best friend."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 343

Text: Bart is closed rn in Oakland so I can’t go to work, I’m so upset....

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I’m so happy I can’t go to work

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 344

Text: Just redownloaded the @achievement app - let's see if it improves my exercise routine!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I download this app again, but realistically I know it won't work.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 345

Text: Just signed up for Apple's Ping, told it I like 'classical' and it points me towards Lady Gaga. It takes a certain genius to be this crap.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Just signed up for Apple's Ping, told it I like 'classical' and it points me towards Lady Gaga. This is really very crap.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 346

Text: i’m going to cut off contact with every single person i know and emerge in a few months o a year from now having lost the ability to physically speak but be able to play the meanest fucking accordion you’ve ever heard in your pathetic little life

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish I could take time for myself to heal in the ways that I need to and emerge from it being able to play the accordion.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 347

Text: It’s funny that you guys thought sports mattered during a pandemic. I simply can not imagine caring about a winning streak rn.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's funny how you guys care about a winning streak right now. I would but my team lost.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 348

Text: ah yes, of the course the summer rain pours when im on foot.

Label: sarcastic

Sarcasm Type: irony

Meaning: "why did it have to rain when im walking?"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 349

Text: Keanu reeves is killing his role in ozark season 3

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The brother in ozark looks just like Keanu reeves!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 350

Text: getting stopped by tesco security is the highlight of my day

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Proper embarrassing that I was stopped by Tesco security. Hate my life.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 351

Text: Yay for being locked out of your own house because you forgot your key

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate being locked out of my house when I forget my keys.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 352

Text: craving an ice pick lobotomy on this Friday afternoon

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would love to go to bed and end this hard day.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 353

Text: my favorite thing about my grandparents is that they're so afraid to talk about me being gay that our catch up phone calls are incredibly short 💘

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say "It's quite upsetting that phone calls with my grandparents are so brief because they avoid topics pertaining to my partner and personal life"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 354

Text: My coworkers play this fun game where they try to describe bars in la crosse &amp; have me guess which one they’re talking about

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My coworkers oddly ask me to name bars in La Crosse based on odd descriptions they give me.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 355

Text: The fair-weather fans in all of these threads. Wake up call. Fleury is a human being. Surprise!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Fleury’s going to make a mistake every once in awhile, he’s only human.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 356

Text: @traves whoa! that's a little too crazy man, slow down

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I guess I would tell the truth and say something like "that is moderately crazy but not that crazy".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 357

Text: Wow. Liam Neeson is coming across as a rational man,isn't he!!?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Just because he had a family member attacked by a black person, doesn't give Liam Neeson the right to kill a random person of colour.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 358

Text: No joke, air-fried Twisted Teas are THE BEST.

Label: sarcastic

Sarcasm Type: irony

Meaning: Twisted Teas are the best.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 359

Text: I find it hilarious that ‘black and white’ or ‘all or nothing’ thinking is considered a cognitive distortion and is a symptom of several disorders, and yet it remains a pillar of American (and Western) culture. It’s almost like…. our culture is toxic 🤔

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The face that 'black and white thinking' is considered a mental disorder symptom and yet remains a pillar of American culture is hypocritical.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 360

Text: It would be nice if my body would let me sleep...

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish my body would let me sleep.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 361

Text: @Mythical So worried about him. But if you're looking to save him, based on the topography I'd say it's somewhere on the east coast. Perhaps the Carolinas?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I suppose I would have simply stated that we all know he is not kidnapped, but it seems like he's just in the woods in North Carolina.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 362

Text: All the shade i have been hearing about Ben Platt being unbelievable as a teenager in the @DearEvanHansen movie boggles me. Does nobody have any memories of Grease??? Name 1 actor on that film who believably looked high school age!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Dear Evan Hanson cast the same type of older actors as Grease.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 363

Text: Drum and bass is dangerous stuff don't you know.. #FabricReview 🙏🏻🙏🏻🙏🏻

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Drum and Bass is not dangerous due its high BPM

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 364

Text: the manliest thing I can think of is when the men from the World Cup passionately sing their national anthem

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: " I think it's really manly when men sing their national anthem"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 365

Text: Love a good cry 👌🏻

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say "I hate when someone makes me cry"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 366

Text: Perfect way to end a 2+ hour @SunCountryAir deley: getting stuck on the tarmack at @mspairport waiting to go to a gate for almost an hour 🙄

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am super unhappy that after a 2+ hour @SunCountryAir deley I have been stuck on the tarmack at @mspairport waiting to go to a gate for almost an hour.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 367

Text: If your website still has a google plus share button, forgive me if I’m not tripping over myself to take your information as credible or current.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: You should remove your google plus share button to remain credible and current since the service is no longer available.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 368

Text: it's too bad i forgot how to play my clarinet so close to my recital

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm so nervous I hope I'll forget how to play to avoid being onstage.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 369

Text: but clinton's emails! oh. emm. fucking. gee. clinton's god damnèd emails. the humanity of it all. 🤮 https://t.co/cibY5Tn9s6

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am genuinely curious to understand the mindset of those who seek to condemn a woman for her choice of e-mail, while giving the obvious pass to a man who boasts about sexually-assaulting (or, if I am being more forthright with my thoughts, "raping") women?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 370

Text: @goldfishbabe101 crispy all day every day over here ✌🏻

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "dry but honestly not mad about it."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 371

Text: @adorinqdwt @dwtridesgnf Yes the racist is so cool!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Racist people are not cool.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 372

Text: Putting the toilet paper roll on so that it hangs under instead of over is a crime worthy of the death penalty

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I dislike when people put the toilet paper roll on so that it hangs under instead of over.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 373

Text: Synthwave communities really love pessimism don't they haha Any upbeat energy and people get upset at ya

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: yes

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 374

Text: @avsmph But how can we possibly deal with a human experience we haven't first relentlessly quantified???

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Our field shouldn't try to force human experience into quantifiable models, but it pretty consistently does.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 375

Text: The Drew Barrymore Show is an absolute trainwreck. Like The Tony Danza Show, every two minutes is a clip for The Soup.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The Drew Barrymore show is one of the worst TV shows ever produced.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 376

Text: It's soooo great that I've taken pain medication and my back is still hurting 😩😩😩😩😩😩

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I took pain medicine for my back, but it still hurts.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 377

Text: Turned 25 today but woke up with $600 from the IRS in my bank account so quarter life crisis has been postponed

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My birthday is today and I got my $600 stimulus check from the IRS.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 378

Text: Only a a President as strong and decisive as @realDonaldTrump would force the FDA to OK a drug even before clinical trial results are in. No need to wait for such silly formalities - people have been taking the drug for years and most are still alive and fine! #OkToTry #Gotrump https://t.co/IdxTJ7kucp

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: Clinical trials to determine the efficacy and safety of a treatment are essential.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 379

Text: I reverse imaged searched a selfie and it under visually similar images it is exclusively asian woman my am I white passing narrative is quaking

Label: sarcastic

Sarcasm Type: irony

Meaning: I used google images to reverse search my selfie, and all of the results were asian women. It was amusing and I was surprised, because I thought the technology would show white women too, since I can be white-passing.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 380

Text: also that jacket he wore yesterday i’m gonna rip my eyes out :/

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: That jacket he wore yesterday made me highly emotional I could hardly stand to look at it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 381

Text: @kagune_kun despicable tweet, my liege

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would likely say, “I disagree with that statement”, or “I don’t think almond milk is gross”.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 382

Text: Lovely day to be stuck at the mall with a dead battery.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's no fun to be stuck at the mall with a dead battery.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 383

Text: So now that it's not getting banned, should I download TikTok?

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Is it really worth it to have a tiktok account?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 384

Text: Horse dancing is my new favorite Olympic sport, I have no clue what’s happening, but this is incredible

Label: sarcastic

Sarcasm Type: irony, satire

Meaning: Horse dancing is a weird Olympic sport and probably shouldn't be a sport in general.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 385

Text: I just love when Twitter decides to reload the timeline seconds after you just opened it up and are in the middle of reading it.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate when Twitter decides to reload the timeline seconds after you just opened it up and are in the middle of reading it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 386

Text: somebody tell these birds to be quiet because they not listening to me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish the birds outside would stop chirping.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 387

Text: this bruh rly told me “Ur anger issues are my playground🥰” so uhh hmu if u wana be friends bc i need new ones k thx(:

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My friend just told me “Ur anger issues are my playground.” That was rude of him.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 388

Text: this just in: phobias CAN be chosen and you CAN get rid of them by just not being scared! 🥰 /s

Label: sarcastic

Sarcasm Type: irony

Meaning: phobias cannot be chosen and choosing to not be scared is not an option for genuine phobias

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 389

Text: every time i send my mom pictures of me and one of my friends doing fun things the first question she asks is if we're on a date what are you trying to tell me mother

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: my mom thinks i'm dating every one of my friends whenever i send her pictures because she thinks i'm lonely.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 390

Text: Are GoFundMe accounts a form of socialism? I don’t have enough money to pay my bills, so let me create an account an ask for money to help pay my bills. ??

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I would probably word it as a question: Do you think that using Go Fund Me to ask for money to pay bills is a form of socialism?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 391

Text: not to alarm anyone but i just saw spider-man by uta

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: ALERT, spider-man is on the uta campus.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 392

Text: Tell the liverpool players to get some beers and just sit on the grass for the full 90 mins. Let leeds score as many goals as they want. #NoToEuropeanSuperLeague

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Tell them to leave the pitch.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 393

Text: Omg thank u for pointing out that I apologize too much 🙏

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate it when people tell me I apologize too much

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 394

Text: Imagine not liking football 🤣

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't understand why people don't like football, it's a great game.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 395

Text: @catboychika Aren't you happy I gave you less competition for ranking

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Sorry for putting off the event for so long TT

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 396

Text: My dad just said to me, “Hey, you’re kinda skinny, can you slip behind the fridge to look at something?” and it might be the nicest compliment I’ve ever gotten. So guys, go tell your girl you think she’s kinda skinny🥰

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Don’t tell your girl shes “kinda skinny”.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 397

Text: Someone in the pub just described the England team as "a bunch of Marxists". Makes you proud doesn't it?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Someone in the pub just described the England team as a "bunch of Marxists". What an idiot!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 398

Text: Yay - snow day, I can work from home - oh wait....

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's snowing, if it wasn't lockdown I'd have to work from home but as I am already working from home it makes no difference to my day.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 399

Text: the audacity of the neighbors to mow the lawn while i'm trying to sleep, at 6:30pm

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My neighbors mowed the lawn and woke me up

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 400

Text: You’re all sickos for being mean to Trump so much for the tolerant left 🙄 anyways George Floyd had it coming

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: People who complain about others being mean to trump are hippocrits

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 401

Text: Gosh sunderland twitter is a fun place to be tonight isn't it. One game. One game!!!

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Sunderland twitter isn't a great place to be tonight.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 402

Text: If only people would care as much about poverty and social equality the way they do jumping up and down for Team Remain or Team Leave.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: People should care more about poverty and inequality than other less important matters.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 403

Text: i hate it here ❤️❤️❤️❤️❤️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate it here. (no emojis)

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 404

Text: When you're feeling all in your feelings, but a certain BEST FRIEND is making you see reason, and maybe you'll be okay. So damn rude. 😤 @LadyDeadlight

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I was feeling badly today, but my best friend gave me clarity and perspective. I appreciate her so much.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 405

Text: Love it wen people try and stop my friends seeing me! Looooolll.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Non sarcastically I would say "I hate it when people try and get in between me and my friends"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 406

Text: 2 x sand eating toddlers for sale. No previous owners. DM for details x

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would love a break from my children who have been misbehaving, for example they keep eating sand.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 407

Text: Day 2348 in lockdown. Never in my life did I think I would utter the words "I've disinfected the chocolate". #coronalockdownuk

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Day 14 in lockdown.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 408

Text: @TheLunaCinema @seetickets absolutely no response from Luna Cinema and my completely factual review on See Tickets has been moderated and will not be published 🤔 great to see @seetickets looking out for their customers. Excellent customer service all round 👏

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The customer service I have received has been terrible

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 409

Text: So our landlord just brought in new sofas which is lovely but in the process broke a table, someone’s cup and spilt tea on the carpet and left saying “you should probably clean that up” thanks Darren 🖕🏼

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Exact same tweet but at the end, saying "fuck you Darren"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 410

Text: Thank you to @OrchardMead for organising pizza and ice cream! It was a lovely end of year gesture 😁💕 Happy holidays everyone - time to collect our time owed in lieu! 😅 #summerholidays https://t.co/324jzGSElj

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am going to enjoy my holiday as I have worked lots of additional hours this year and I am owed the time the off.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 411

Text: Yes you can break all the rules for Christmas and risk serious fines and killing your loved ones with a deadly virus OR you could ✨stay at home✨

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Please do not break the rules for christmas and risk serious fines or killing loved ones. Please stay home.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 412

Text: Entry level jobs that require 3 years prior experience 💕💕 ly 💕💕

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate entry level jobs that require years of experience

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 413

Text: Anyone else hear some like thunder or something?

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: Anyone else hear that thunder?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 414

Text: why is the weather having a mid life crisis

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: “why is up with the weather at the moment”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 415

Text: Roses are Red Violets are Blue My first love was Championship Manager Tommy Svindal Larsen and Kennedy Bakircioglu #HappyValentinesDay

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Something along the lines of I was too sad, pathetic and immature in my teens to try to find romance with human people, so instead I invested a huge amount of emotional hope, energy and anguish into a fake computer simulation.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 416

Text: When your @Apple delivery gets stolen by a UK Mail delivery driver and the police know who it is but I still don’t get taken seriously🙃🙃🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish that the person who stole my laptop would be arrested

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 417

Text: Cheers @ASOS delivery lady for dropping my parcel off covered in coffee 😒👌🏼 https://t.co/UzY4gJS9DE

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Not pleased the delivery lady spilt coffee on my parcel

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 418

Text: "coping strategies to help with tinnitus and hearing loss: see a doctor!" Wow thanks internet

Label: sarcastic

Sarcasm Type: irony

Meaning: "This is not at all helpful information."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 419

Text: I love how men know they have a baby on the way in one month and they decide to go out and buy a brand new mustang wow

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I dont like how my childs father bought a brand new mustang a month before she was born, because we could not fit her carseat in the back seat of the car, making it unsafe to drive with the baby.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 420

Text: Both kiddos have a cold I don't feel good and now I think my oldest is having stomach issues, oh what a fun night!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: This isn't a fun night both my kiddos are sick.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 421

Text: So, a country that is trillions in debt, with numbers approaching 13 million on surgical waiting lists and hurtling towards facism regime, is talking about rescuing people from a facist regime?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: This country is not a "free" country anymore.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 422

Text: It's nice to see some heritage organisations are doing the right thing and putting the safety of their staff, visitors and volunteers first. Wonder what that's like... ...for reasons, this is aimed at nobody.

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: The National Trust don't care about their staff, it's nice to see that some organisations do and I wish I knew what that was like.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 423

Text: you would think the odds of me sitting next to the exact same stinky man three bus trips in a row is highly unlikely. alas I seem to be a lucky gal

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I can't believe the same man ended up sitting next to me on the bus three times in a row. He stinks, so I'm unlucky.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 424

Text: the only ppl who should be worried about Biden’s tax plan r the ones who get gifts for easter

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: We should all be worried about Biden's tax plan

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 425

Text: Always glad to live in Kent 🙈🙈

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's absolutely going to be awful living In Kent after Brexit considering the issues with Lorries.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 426

Text: This is awkward... @hollywills is a Diet Coke ambassador 🤯. #ThisMorning

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I probably wouldn’t have said it

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 427

Text: Thinking about that time Blizzard had the brilliant idea to change everyone's name on their forums to their real names. God, what an idea that was.

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: "The idea Blizzard had to stop people from being terrible on the internet was a bad one that would have led to people being doxxed at best, murdered at worst."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 428

Text: It’s so fantastic when you pay £800 a month to live in London in a fully refurbished house and wake up with water dripping on you from the upstairs en suite XXXXXX

Label: sarcastic

Sarcasm Type: irony

Meaning: I am fuming that I have paid so much money to live in a house with a leak

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 429

Text: Just disposed of a dead opossum. Good morning!

Label: sarcastic

Sarcasm Type: irony

Meaning: Disposing of a dead opossum was not a pleasant way to start my day.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 430

Text: Thanks to India for being so inept. I was hoping for a full day of cricket, got snacks and everything. Cheers. You could have at least tried. #bbccricket #INDvENG #ENGvsIND #Cricket

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am pleased with my team’s performance

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 431

Text: i hope u sleep maybe forever maybe not lol

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i wish you wake up normally

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 432

Text: I can't wait to name my children after things I will never have. My daughter will be Hope. My son will be PS5 because that shit is expensive.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: In this tweet I would probably say. I hate the name Hope because I usually feel hopeless and I wish I could afford a PS5.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 433

Text: it's funny my mom thinks i possess no remorse when i feel remorse everyday for existing 😎

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i hate how my mom thinks i feel no remorse, when she has conditioned me to feel remorse nearly everyday for simply just existing alongside her

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 434

Text: who needs an alarm when u can have the low rumbling voice of a stranger to wake u up in the morning 🥰

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish I hadn't been woken up by a stranger talking loudly.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 435

Text: where can I hand my notice in for mental illness? been working at the same thing for way too long and it’s time for a change.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm fed up of being mentally ill and would like to get better

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 436

Text: @MailOnline Another misogynistic, homophobic rapper.. how shocking!

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Many rappers seem to be homophobic.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 437

Text: We get it ESPN. Sawx and Yanks. Let's go meteor.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: ESPN is yet again shwoing the Red Sox and Yankees. Don't they have other teams they can show?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 438

Text: head is pounding, spent £25 on ubers last night and I have a 3000 word report to write :) yippee x

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am really hungover and spent too much money last night even though I have too much work to do

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 439

Text: Inspired by the ‘dinner with Jay Z’ guy still going strong. I choose now to believe him

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: I do not like this man

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 440

Text: You know what makes a 15 minute wait for the bus even better, rum leaking all over the contents of your bag 🙈😫

Label: sarcastic

Sarcasm Type: irony

Meaning: I've already been waiting 15 minutes for the bus and now I've spilled rum all over my bag.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 441

Text: @cassieecote413 you can copy mine

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say the same thing as I tweeted, but it would actually be relevant to the girl I am replying to.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 442

Text: For a good laugh, follow me over on @vsheltonsports to see my best attempt at covering sports business news for class this semester.

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: I would say "I have zero interest in sports, so definitely regretting the decision to sign up for a sports business class that's making me tweet about sports every day..."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 443

Text: First day of school and spectrum internet has already shit itself. Amazing

Label: sarcastic

Sarcasm Type: irony

Meaning: I hate spectrum internet for already messing up so early on the first day of school.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 444

Text: alllllll nighter. woohoo

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: All nighter. Not every exciting

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 445

Text: "Alexa add small bananas to the shopping list." I've added smooth armours to your shopping list." Gee thanks Alexa! #alexa

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i asked my smart speaker to add small bananas to the shopping list, but she misheard me.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 446

Text: Every time I see an establishment with paper straws I turn a little bit Republican

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I do not enjoy paper straws

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 447

Text: Love that someone broke into my car this morning

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could say "I hate that someone broke into my car this morning."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 448

Text: I hate you so much @Eagles

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Being an Eagles fan is disappointing

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 449

Text: So weird how Venmo hasn’t venmoed me yet really thought I was the one

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: there is no way I would win a contest that millions of people are entering

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 450

Text: I love leaving the doctors office in tears. I need this kid to just decide to leave my body so we can be done and home together.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate leaving the doctors office crying.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 451

Text: Joey the genius! I wish i was as brainy as him #towie

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: joey essex is not a genius and i am glad i am clever

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 452

Text: I'm hoping my social work class party is going to involve tequila and chip and salsa 💃🍹🎉👨

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hope my school of social work party is fun and not boring.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 453

Text: imagine being able to sleep haha can’t relate

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I can't sleep

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 454

Text: only have to physically be in uni for an hour a week looool mmmm take my 9k xxxxx

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: 9k is ridiculous for 1 hour of in person teaching a week.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 455

Text: Nice to see @Cardiffbus have started the new year off with the usual crap service. Just love waiting for a bus that doesn't turn up

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate waiting for buses that don't turn up

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 456

Text: Just gotta realize no ones interested in what I have to say 👌

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: People are interested in what I have to say. I'm just having a bad day.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 457

Text: nothing quite says hello 2020 like hypothermia 🥳

Label: sarcastic

Sarcasm Type: irony

Meaning: I would prefer to welcome the new year without Hypothermia

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 458

Text: you know what’s a novel concept? rapists and sexual assaulters not only ruin the lives of their victims but also THEIR OWN LIVES. yeah. not the victims testifying. maybe if you didn’t want rape accusations then DON’T RAPE. also a novel concept.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Rapists ruin their own lives, not the victims testifying.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 459

Text: our lord and savior, frank ocean, has saved us all once again.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Frank Ocean really did something with this new music.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 460

Text: i stg i probably talk to my tv more than i do to actual people whoops rip social life

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I talk to more people than i do anything

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 461

Text: Will pessi sign for man city

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Is messi going to sign for man city?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 462

Text: Life is about eating chicken finger and getting drunk

Label: sarcastic

Sarcasm Type: irony

Meaning: Life is about happiness and friendship

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 463

Text: I’m still confused about DaBaby’s point? Like would you have said “everybody without cancer out your lighters up”??? like what sir https://t.co/EqcbAEkIJM

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Why would you say something like that? It almost sounds the same as if you said "etc"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 464

Text: ate a bagel with cream cheese earlier and the impending doom immediately vanished from my mind

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Eating a bagel with cream cheese cheers me up because it tastes good

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 465

Text: my hobbies include leaving projects for the night before and then complaining that the teacher didn't give us enough time 🙃🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: When I procrastinate I tend to blame tbe teachers for not giving enough time although it is entirely my fault

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 466

Text: Death by Zara fitting room

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say "The Zara dressing rooms are the worst because the lines are long".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 467

Text: Amazing how fast this team can go winning from 13 straight to losing three in a row. Lol. Horrible managing tonight. I really hope this Boone experiment is over soon.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The Yankees are a really bad team right now and it's amazing how fast they can fall.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 468

Text: So my Twitter feed has to show me what tweets people I follow like. ...😐 If I unfollowed you, just know I'm tired of seeing porn

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Twitter is showing that some people I follow are liking porn and I need to unfollow them to stop seeing that

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 469

Text: can't wait to cop tickets to see the cracker quartet

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't want to get tickets to see One Direction without Zayn.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 470

Text: Hands up who remembers when EVERY blogger and their dog was a brand ambassador for Coconut Lane 😂

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Who remembers when some bloggers were brand ambassadors for Coconut Lane? - i.e. without any emojis.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 471

Text: employer: so what are your strengths me: i’m smart i’m funny i’m nice i’m cool i’m creative i’m hardworking i’m made of wood i’m honest i’m fast i’m awesome i’m hot i’m chronically ill i’m little i’m in demand i’m

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could elaborate more on the strengths that make sense (creative, hardworking, etc) and to include those that are clearly false, I could make it a metaphor that would show the employer that I can think outside of the box. Of course, some of the original message could be left out for a more realistic approach.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 472

Text: Who's ready for monsoon storms allllll weekend?!?!

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: There are going to be monsoon storms all weekend. Is anyone ready for them?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 473

Text: Has any couple ever put furniture together and stayed together afterwards??? Asking for myself

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could have said putting furniture together with your significant other is not easy

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 474

Text: I spend the day sitting or napping, I ration my food like a psychopath, and I take one walk a day. I am my dog. #Covid_19 #CoronaVirusUpdate

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My days are spent doing nothing.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 475

Text: Well. That went well. #BelgianGP

Label: sarcastic

Sarcasm Type: irony, satire

Meaning: No start to the race? This doesn't look good.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 476

Text: love waking up in a panic 🥴🥴

Label: sarcastic

Sarcasm Type: irony

Meaning: I do not like waking up in a panic

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 477

Text: Oh boy, a song I'm gonna play on repeat until it makes me physically ill to hear it! Thanks FOB

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I can't stop listening to this new song from FOB"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 478

Text: don’t make me rewatch panic 🤨

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “I’m going to rewatch panic on amazon”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 479

Text: pay it forward is honestly one of the worst movies I've ever seen why would would anyone make an ending so sad I've been crying for 30 min

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The ending to Pay It Forward made me extremely sad and I’m not happy about it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 480

Text: hello to all three of my followers, this is my big return to twitter

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I'm posting on Twitter again.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 481

Text: we used to make fun of rich men for using 3in1 turns out they were never using anything at all 🤮

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: it's really funny how rich people think that they aren't held to the same personal hygeine standards as normal people

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 482

Text: Thanks @myhermes for losing my parcel but giving me someone else's. I'm nice enough to go give it to them though. Please DM me back soon 😐

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am unhappy that you have lost my parcel

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 483

Text: Anyone need a body for a human sacrifice? Trying to find a valid excuse to not go to work today.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I need a valid excuse to call-out today.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 484

Text: @inkofreality @StrangerTings1 @nytimes You're so close to understanding baseline biasing. You can get there, I believe in you!

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: This is simply an example of baseline biasing, i.e. if 90% of people are vaxxed and vaxxed make up 30% of hospitalizations, still implies extremely effective.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 485

Text: Mine and @livlawrencex snapchats are just stunning👌

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: Our Snapchat’s are incredibly unattractive

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 486

Text: They should just put a wall around the pitch to stop the ball going out

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The ball leaves the pitch a lot

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 487

Text: @32watto Neighbours

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'd suggest a programme like entourage

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 488

Text: My PS4 Pro has P.T on it, which is somewhat funny as it was taken down before the PS4 Pro was even released #konami #PT #SilentHills #Spooky #PlayableTeaser #Kojima

Label: sarcastic

Sarcasm Type: irony

Meaning: I have managed to transfer PT to my PS4

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 489

Text: never drinking again

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I had a bad experience drinking today

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 490

Text: I reckon I could have put that in the net Morelos sir

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: That goal should have been easy for Morelos!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 491

Text: what a great day to be stuck inside 🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's a terrible day to be stuck inside.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 492

Text: Happy birthday to me!! I’m 30! 😭

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm 30! Id like to wish myself a happy birthday

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 493

Text: Every time you complain about neopronouns or xenogenders we add five more

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Stop complaining about peoples individual gender experiences

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 494

Text: naming my son onickolas in honor of my love for @NICKIMINAJ

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Wouldn't it be funny if I named my son Onickolas in honor of Nicki Minaj.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 495

Text: Enjoy the bars and vineyards✌🏻 Make sure to send postcards to the people dying in your local hospitals. I’m sure they’ll be glad you’re not bored anymore

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: If you’re going to bars and vineyards right now, just keep in mind the people who are dying in hospitals from COVID. Your entertainment is not worth their lives.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 496

Text: @jabadgo @Nibellion Don’t run it on a school-provided laptop

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Are your computer's specs up to par for the game?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 497

Text: gotta love living in a country where it’s easier to get an AR-15 than it is to get coronavirus testing 😍😝

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: When I wrote this tweet, COVID testing was really inaccessible. That has somewhat changed but I was really trying to make a comment about how healthcare is a human right and how poorly our country is handling the pandemic. Owning a military-grade weapon isn't really necessary for human life. While I absolutely believe in the right of the working class to arm themselves (although not with an AR-15...), I just think it's ridiculous the barriers that are put up for people when accessing quality healthcare. I think it's run like a business in this country, and it's immoral.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 498

Text: thinking about how no one is obsessed with me 💔

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Thinking about how no one has a crush on me"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 499

Text: If the sound of the rain outside wasn’t bad enough I’ve now got my neighbours climbing onto their roof and shouting ‘I love blowjobs’, perfect background noise for me trying to study 👍🏻

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: this is the worst background noise to study with.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 500

Text: It was the jerseys

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Theyre embarrassed of their uniforms so theyre playing badly

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 501

Text: Sooo... @adamlevine was that "Nice!" and double fist pump for the show or @shakira s ass that you were checking out? @NBCTheVoice

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: "Adam Levine sure was checking out Shakira's ass last night"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 502

Text: @MarkHendyHR Only joking... keep it real. HR professionals have a life too... 🤔

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Only joking. Keep it real. HR professionals don’t have a life.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 503

Text: Shaving in the shower without your glasses/contacts is EXACTLY like performing blind surgery 👀🔪

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Shaving your legs without your glasses/contact lenses is incredibly difficult.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 504

Text: if jesus was resurrected again i would vote for him

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Our candidates for president are so bad.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 505

Text: New levels of desperation: sleep is now truly insignificant to me. In fact, it’s a downright annoyance.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: New levels of desperation: my lack of sleep is not a joke, in fact it’s a downright annoyance

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 506

Text: So I have an exam tomorrow, but likeee if the country is about to turn into a war zone does it really matter??

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I have to take this exam even when the world is falling apart.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 507

Text: Absolutely LOVE spider season! I love crying in fear. I love not being able to sleep. I love people telling me that I'm being ridiculous. I love hearing "it's not gonna hurt ye". I love using every orange peel, conker and peppermint oil known to man. I love fear. 😑

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: That I am now living in fear and hate spidershttps://twitter.com/QueenAtoB/status/1430308715744440322?s=19

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 508

Text: Getting a dog was single handedly the best and worst thing I’ve ever done..can’t imagine life without her and I can’t live without her.. Make sense?

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Getting a dog was the best thing I could’ve ever done.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 509

Text: cant wait to dance with harry styles and the delta variant at their concert in november!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am terrified to go to the harry styles concert and be exposed to the delta variant.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 510

Text: really honoured to have shared a coach today with a group of girls who didn’t know downing street was real and thought the prime minister and the queen lived together at buckingham palace

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “I dislike sharing a coach with...”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 511

Text: It’s “let’s see how many crumbs I can find in scarf” szn.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate carrying crumbs in my scarf all day, everyday.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 512

Text: The best part of going out, is waking up at 2PM the next morning wondering whether you're dead or not and what day it is. 😂😳😀

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The worst part of going out is waking up the next day, wondering what day it is and if you’re dead.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 513

Text: Lucky for @JoelEmbiid , only MVPs get tossed for those kinds of fouls #76ers #ATLvsPHI #hawks #NBAPlayoffs

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say Embiid wasn't good enough to win MVP

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 514

Text: @JasperSmiith @LentonDNRA @ShearerWest @registrarism @UniofNottingham @CllrDaveTrimble @SallyLongford @CllrDavidMellen @LilianGreenwood @MyLWE @MyNottingham Yeah just a coincidence that infection rates go up and down dependent on when students are in the area or not, also tallies in with the parties being attended by up to 3 times the amount of allowed attendees. Definitely not students 🤔🤦🏽‍♀️🙄

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Yes there is a link and students are to blame for the rise in covid cases in our area.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 515

Text: The most 2020 quote of the year: Me: we should go to the Van Gogh Museum! Little Brother: is that the donny with one ear?

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My brother referred to Van Gogh as the Donny with one ear.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 516

Text: I’ve always known #Bez is my spirit animal but seeing the mess he makes on @MasterChefUK confirms it 100% what a legend that man is

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Bez might be messy but he's a great chef

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 517

Text: Nothing can be further from the kickoff of the NFL season than a pre-game performance by Ed Sheeran. Nothing against him but he just doesn't inspire me to watch football. #Football #NFL #Weak #TestosteroneDeficiency https://t.co/JTI2qgSxUq

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Ed Sheeran should not be the opening act to the launch of the NFL season.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 518

Text: I love when I learn about stuff I've apparently done and said from people😂

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I absolutely hate when I learn about things I have done from other people.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 519

Text: @sdeditgirl You should know a true Oregonian doesn't use umbrellas!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I really will need an umbrella in Oregon."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 520

Text: How is it possible that Sly Stallone’s ‘Cobra’ is both the best and the worst movie ever made?

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: I kind of dislike and like Cobra the movie the same amount!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 521

Text: people who say that they’re allergic to pineapple are pathological liars!!!!!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I feel like too many people say that they're allergic to pineapple when they really aren't.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 522

Text: I love calling my mom early in the morning and waking her up, I take it as pay back for all the times she never let me sleep in 😜

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It’s funny how my mom used to wake me now I wake her.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 523

Text: Great night last night! Muggins here is the commis chef crouched down in the corner. Seriously an honour to help raise money for @acf_uk and work alongside these stellar chefs. Thanks for having us @nickg67 @frontlinechef! https://t.co/mkiTEpMzaz https://t.co/SVgdFYHyi4

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: I worked extremely hard tonight and am crouched down in the corner l.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 524

Text: @GainzyXBT Actually I've extrapolated based on the last daily candle and it turns out BTC will be sub-zero by December. The math doesn't lie.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm not entirely sure you -can- say the same thing non-sarcastically. I suppose... 'Constantly calling for lower targets is ridiculous.'

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 525

Text: "Should I wear my lime green pants?" dad its 4th of july...

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Should I wear my red and blue pants

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 526

Text: How does one find motivation to do basically anything? Asking for a friend.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "How does somebody find motivation to do basically anything? I haven't had motivation in ages."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 527

Text: Sick of being healthy already pissing like a racehorse !! Keep Well hydrated Han 4th litre of water 💧💦

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Not enjoying being healthy , going the loo far too many times .

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 528

Text: James Harden is allowed to travel every time he drives apparently

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The refs missed a few traveling calls on James Harden.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 529

Text: South Park being taken off Hulu is the worst thing that’s happened to me personally in 2020 and like.. my dad died

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: South Park being taken off Hulu was a bad thing to happen in 2020, but not worse than my dad dying.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 530

Text: do i like him or is his hair just curly??

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: People with curly hair are attractive.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 531

Text: “You’re never going to have a white boyfriend are you Jess” Nah don’t think so Mum

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: You’ve had a mixed lot of boyfriends haven’t you?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 532

Text: flew into a rage this morning bc i couldnt find my karaoke mic so yeah i would say things are going well for me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm not doing great mentally right now.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 533

Text: My favorite part about running on the track is seeing how high my heart rate gets just walking up the stairs to it.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My heart rate spiked when I walk up the stairs to the track

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 534

Text: Most people have security cameras for protection. Ours acts as a DVR

Label: sarcastic

Sarcasm Type: irony

Meaning: The events that happen around our house while we are not here can be very entertaining

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 535

Text: Is there a zombie apocalypse going on upper street

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Why does everyone look so dead on Upper street

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 536

Text: 💫jsc bonding nights💫🥰🥳

Label: sarcastic

Sarcasm Type: irony

Meaning: I would say "bonding with the jsc homies".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 537

Text: tiktok's full name is tictactoetok

Label: sarcastic

Sarcasm Type: irony

Meaning: Tiktok's name is Tiktok

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 538

Text: you ever completely embarrass yourself on zoom and decide to drop out of college?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: “I am embarrassed because of what I said in class on Zoom”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 539

Text: thats it im packing my things and moving to italy see u all in a month xo

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm so done with everyone, I wish I could move away to Italy.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 540

Text: @kashirenaii i would never go to six flags with u

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would go to Six Flags with you.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 541

Text: next person that puts beomsil on my tl has to deal w me crying on the floor

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Stop putting beomsil on my timeline.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 542

Text: its 3 30 am and I have decided the only redeeming quality of a male is that I can put my freezing cold toes on him and leach his warmth

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I love putting my freezing cold toes on men to leach their warmth.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 543

Text: just met the love of my life don't text

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: just met this man i have been following for two years. please text me so i can scream about this forever.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 544

Text: bad romance by lady gaga is the best song to ever come out of the american music industry and anyone who says otherwise is a liar

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Bad Romance is a bad song

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 545

Text: Well done to the guy who was charging down the stairs at Ealing Broadway and sent me flying, you made me cry.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Shame on the guy who was charging down the stairs at Ealing Broadway and sent me flying, you made me cry

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 546

Text: Day 3 of night shift: “Can I get a triple shot puppuccinio?”

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: I need 3 shots of coffee

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 547

Text: Funny Quote of the Day: "I believe in luck: how else can you explain the success of those you dislike?" - Jean Cocteau

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Everyone is allowed good luck no matter if you like them or not.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 548

Text: @trpalomo Those boots must be tasty for how much they're choking on 'em 💀

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: No.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 549

Text: Good morning September... Hello tonsillitis :(

Label: sarcastic

Sarcasm Type: irony

Meaning: Good morning Twitter, I just woke up with tonsillitis. Hope I get better soon.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 550

Text: Someone should’ve had me committed the day I decided to buy a pair of non-stretch denim jeans

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate non-stretch denim jeans.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 551

Text: @KellyMartin_UK @Morrisons You’re right, it’s all one big conspiracy. You should boycott the NHS too, they’re in on it as well

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: If you truly really believe there is a conspiracy you should boycott the NHS too

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 552

Text: @SkySportsBoxing if i think you would have a chance against fury i mean its easy for some broken bodied old boy to beat the best in the world

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: Haye as a competitive fight against fury which is a 50-50 fight and could go either way

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 553

Text: Just saw a cop riding a segway?!! So glad my taxes paid for that.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't approve of my taxes paying for cops to ride segways.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 554

Text: It really bugs me when teachers uncap and recap highlighters three or four times per book when marking - Poor time management! #efficiency

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Use the hashtag #wastedtime instead

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 555

Text: "I can't wait to be a piece of shit with a bachelors degree"

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Once I get a Bachelor`s degree I will be the same person, just with a slip of paper.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 556

Text: Love it when someone buys a £175 coffee machine in Paris with my debit card 😕

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Gutted that someone has used my card to buy a £175 coffee machine.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 557

Text: @RealCandaceO Ok so when does the anger and bitterness start? Just so I can prepare properly…

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't believe that this happens to everyone, and it won't happen to me.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 558

Text: I'm so glad the clocks just went back, I have this whole extra hour of insomnia to play with.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: If I weren’t insomniac I’d be pleased to have an extra hour.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 559

Text: Please consider map filters on online mutliplayer. Pretty pls, thanks @CallofDutyUK

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I want map filters on COD

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 560

Text: Got a bloody screening invitation for a massive film - YES THAT ONE YOURE THINKING OF - and both screenings are on school days 😭 tempted to quit teaching tbh

Label: sarcastic

Sarcasm Type: irony

Meaning: I would like to go to the film screening if I could

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 561

Text: Having morning sickness when you're not actually pregnant is all the fun

Label: sarcastic

Sarcasm Type: irony

Meaning: Having morning sickness when you're not actually sick is not fun!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 562

Text: They really said you can’t have nice weather AND no lockdown for your bday this year huh

Label: sarcastic

Sarcasm Type: irony

Meaning: can't i have nice weather for my birthday even if we're in lockdown?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 563

Text: “it’s hotter in the america right now and it feels fine british people are just being dramatic 🙄” QUICK ARE YOU SAYING THIS INSIDE UR AIR CONDITIONED HOUSE ‼️‼️‼️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: americans can’t say the heat in england is nothing when they have ac

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 564

Text: Just had a flashback about a boy and nearly threw up in my mouth

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Just thought about a boy I used to sleep with and felt uncomfortable.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 565

Text: @Ciara87C @RachaelSmarty @SashaHumphreys2 my tinder convos have been leaked

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: This man doesn’t like Irish girls which is very different to me.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 566

Text: Dear @krispykremeUK, I see your enticing #Thanksgiving offer that ends on 2 Dec. I wanted to ask if you're aware that #Chanukah starts on 10 Dec, continues for 8 days &amp; that traditional Chanukah fare is actually #DOUGHNUTS ?? 🍩🍩 #justsaying #AskingForAFriend #opportunity

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Dear @krispykremeUK, I note your #Thanksgiving offer that ends on 2 Dec. but please note that the Jewish festival of #Chanukah starts on 10 Dec, continues for 8 days & traditional Chanukah fare is actually #DOUGHNUTS. Please consider a special offer for this, too.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 567

Text: Wow great album from Kanye. v John Cage 4’43 vibes x

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: Kanye needs to actually release his album.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 568

Text: Just got in, how’d Liverpool get on?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Liverpool did not play very well.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 569

Text: Actually considering applying for the undateables

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Why is my lovelife so dead?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 570

Text: @JoeTalkShow @EdwardNorton Get ratioed, then tell us more about the "hate-filled left," especially about how the Republicans and independents who voted for Biden are somehow part of that group 🤣

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Biden is a liberal, not a leftist. Liberals are center-right. People who voted for Biden came from everywhere on the political spectrum, including conservatives and independents, so stop trying the blame some imaginary 'hate-filled left.'"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 571

Text: thank you kind person that stole my ATM card, you must have known I wanted to sit at the bank all day.. half hour and still waiting #mondays

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Someone stole my bank card and now I have to sit and wait in the bank all day unhappily.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 572

Text: So excited to start this job!😊

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I’m not exciting to start this job

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 573

Text: Maybe if we didn’t comment on things that don’t concern us, the world would be a happier place?? But what do I know🤷🏻‍♀️

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I know the work would be happier if we all stopped commenting on things that don’t concern us

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 574

Text: dad: "are ya sending any of those boys from 5soz (wtf is a 5soz dad) a valentines gift?" me: yes dad yes i am cuz im dating all of them duh

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: im not dating any of them

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 575

Text: I just read, "oftenly" and threw up in my mouth a little.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would point out "oftenly" is not a word in the English language. I would explain the grammar and correct the weird to often

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 576

Text: I unsubscribe from being an adult, its not for me

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: being an adult is really hard

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 577

Text: i love siriusxm. siriusxm is my friend

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate SiriusXM

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 578

Text: A whole 2% off for a single order, rejoice

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: 2% off of single order is a basically useless coupon.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 579

Text: Can’t wait to see Ed sheeran at tramlines tomoz x

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: Ed Sheeran isn't at Tramlines and I'm glad about it

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 580

Text: @kirkkorner "But it's a deterrent" 🙄

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Making 'theft of a dog' a new offense in English law is definitely not an effective deterrent to potential dog thieves

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 581

Text: Great start to the day Neros was shut and now I'm going akip on the bus 😴😵

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I had the worst start to the day as cafe nero was shut and I couldn’t get a coffee

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 582

Text: @Torialou78 My excellent photography skills! :p lmao!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I do not think I did a very good job of taking that photograph!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 583

Text: @SIazVest @rodneyjaguars57 Fuck you got me there, you better get back to getting upset and jealous over successful and talented boxers

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “Fair enough you got me there”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 584

Text: Just rediscovered that my nose is always in my field of vision so I will unfortunately be dropping out as I cannot continue my assigned readings in peace

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Just rediscovered that my nose I always in my field of vision which is making it difficult to focus on my assigned readings.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 585

Text: There is nothing new in an oliver james publication that can't be found elsewhere for free. He's a leftist living a straight bourgeois life

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Be more direct.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 586

Text: Sometimes I wonder if Priti Patel and Boris Johnson think that the Prime Minister is the one with the best K/D ratio. It would make sense with the whole 'let the bodies pile high' thing.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Priti Patel and Boris Johnson are doing a terrible job dealing with Covid.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 587

Text: Just won 3 cents on HQ words...early retirement here I come 😍

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I won 3 cents on HQ trivia, that is not enough to buy anything at all

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 588

Text: Schadenfreude x

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: After many years it is brilliant to laugh at germany

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 589

Text: Being a mom with an autoimmune disease means I am a grown ass woman that caught hand, foot, and mouth from my daughter. My Hashimotos sucks. Thanks for all the sicknesses I so graciously suffer and should not be suffering at 40.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wouldn't because sarcasm is the only weapon I have against this stuff

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 590

Text: My gf has been in the Hamptons nannying for a few hours and she has already been to a POLO match. Is she in GOSSIP GIRL?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: My gf has been in the Hamptons nannying for a few hours and she has already been to a POLO match. It’s like she’s in “Gossip Girl”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 591

Text: my computer does this fun thing now where it shakes in a way that exactly replicates what happens to my vision when i forget my meds so that’s exciting !

Label: sarcastic

Sarcasm Type: irony

Meaning: Yes

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 592

Text: I'm just living off salads and yogurt and loving it tbh

Label: sarcastic

Sarcasm Type: irony

Meaning: I am living on salad and yogurt and it's getting old

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 593

Text: 💕 tip for baking bread! 🍞🥐🥖 you can use the yeast in your dog's ears to substitute active dry yeast or instant yeast in a pinch! 💕

Label: sarcastic

Sarcasm Type: irony

Meaning: It would be gross to use the yeast in your dog's ears for baking bread.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 594

Text: You guys, how cool would a British version of Breaking Bad be? Lol jk, they have universal health care so Walter White would never have to resort to cooking meth in a trailer to be able to fund his cancer treatment.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: We should have a healthcare system more like the UK which provides free services for all citizens

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 595

Text: Ain’t never really had a daddy so I’ll never really need one 🤷🏾‍♀️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I never received help from my dad so I don’t need any help now .

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 596

Text: 2 minutes into the book and I already hate the main character. Lovely

Label: sarcastic

Sarcasm Type: irony

Meaning: I do not enjoy the main character of this book.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 597

Text: i would rather be outside reed timmers car in f3 tornado winds than go to work today

Label: sarcastic

Sarcasm Type: irony

Meaning: I do not want to go to work today at all.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 598

Text: North Dakota: *has one decent week of weather* Mother Nature: NOW I SHALL CAST OUT THE SUN AND BRING THE COLDEST OF RAINS UPON THY SUPER, DUPER FLAT LAND.

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: North Dakota had a nice week of weather followed by a rainy day.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 599

Text: I never feel more empowered than when I’m listening to ‘this is me’ from camp rock

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: I never feel more cheesy than when I am listening to 'this is me' from camp rock.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 600

Text: Happy birthday to me. I got pinged and can't leave the house 🥰🤡

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Unhappy birthday to me

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 601

Text: don't cry because it happened, smile because it's over &lt;3

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Don't cry because it happened, be proud that you made it through.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 602

Text: @rickyberwick And you said Donald trump was racist 😑

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I guess Donald Trump isn't racist.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 603

Text: so the royal family is sound with pedophiles but as soon as a mixed race baby comes into it they’re scared ? makes sense 🥴

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: ‘it doesn’t make sense’

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 604

Text: IF ONLY PEOPLE WOULD RAKE THE FORESTS. #Debate2020

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The president seems to believe that merely removing leaves from forest floors would prevent forest fires.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 605

Text: I really hate the new TikTok voice over voice - she sound annoying af

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: The new Tik Tok voice over is annoying.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 606

Text: Mad how many cars they make now without indicators 🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Mad how many people don’t use indicators these days.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 607

Text: my car is acting up AGAIN for like the 3rd year in a row and I’m just going to drive it into the river at the point

Label: sarcastic

Sarcasm Type: irony

Meaning: "my car is acting up AGAIN for like the 3rd year in a row and I'm really frustrated with it right now"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 608

Text: My living room feels really lively now. I’m recklessly sipping tea absorbing choons #TaeSup

Label: sarcastic

Sarcasm Type: irony

Meaning: In spite of the fact lockdown means I cannot go to a live gig, this stream brings me joy in private

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 609

Text: Lil Pump is the Nelson Mandela of our generation

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: Lil Pump is not the Nelson Mandela of our generation

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 610

Text: I too enjoy making shit up and pretending like I understand basic economic principles https://t.co/cHDBHaxBBR

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: This is completely made up and goes against basic economics.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 611

Text: Just nearly cried in the tesco express because they didn’t have the cheese pizza or the back up pizza I wanted. My mental stability is strong today.

Label: sarcastic

Sarcasm Type: irony

Meaning: Just nearly cried in the tesco express because they didn’t have the cheese pizza or the back up pizza I wanted. My mental stability is not strong today

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 612

Text: this time tomorrow i'll be dying at school Cannot Wait!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i am not looking forward to school tomorrow

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 613

Text: rewatching degrassi for the millionth time

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: “Watching Degrassi again “

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 614

Text: Matt Hancock is a top shagger

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Matt Hancock is a wanker

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 615

Text: I’m gonna miss scantrons shortening my name to “Christ” after 16 years

Label: sarcastic

Sarcasm Type: irony

Meaning: I'm not going to miss scantrons shortening my name to “Christ” after 16 years

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 616

Text: Day 55 of Lockdown. Finally bought some jigsaw puzzles. Absolutely cannot wait for them to come, highlight of my day (maybe even year)

Label: sarcastic

Sarcasm Type: irony

Meaning: I’m bored in lockdown which has now resulted in me buying jigsaws like an old woman

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 617

Text: Don’t you just love it when they dig up your road at 8:30am on a Saturday 😠

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate it when I’m woken up by workmen digging up the road at 8:30am on a Saturday

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 618

Text: Just watched a man smoke crack on the R train in front of 3 families. New York is healing ✨

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Just watched a man smoke crack on the R train in front of 3 families. New York is continuing to become less safe."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 619

Text: Using my recently acquired video editing skills on myself for a change. An oral #presentation assignment on #healtheconomics is as much fun as it sounds 🗣🎥 https://t.co/1LKHVyupie

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: a presentation on health economics is no fun at all

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 620

Text: we love when the power goes out at 6:30 in the morning on a wednesday https://t.co/BBIQ7ZYS3x

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I get annoyed when my power goes out randomly.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 621

Text: It’s spring, so that means it’s time for couples to leave the bar across the street and come fight under my window at 2 am again ❤️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate when drunk couples fight outside of my apartment

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 622

Text: Get ready for the next big horror game this season, Slender Suburban Man

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Id say something along the lines of "thank god theres not a game out there called Slender Suburban Man"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 623

Text: If I were the Red Sox I would simply play the Orioles more

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The Red Sox probably wish they could play the Orioles all season.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 624

Text: Wow... the universe gave me the task of a potty training a whole human? the audacity.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I absolutely hate potty training toddlers.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 625

Text: @Mike_Fabricant This aged well

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: This didn't age well.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 626

Text: tanning in this heat is an extreme sport

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: tanning in this heat is difficult

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 627

Text: Just almost got hit on the highway by a @CityofSanDiego truck 🤪 tysm for making me feel safe guys!!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would write “Just almost got hit on the highway by a @CityOfSanDiego truck! Wish we had gotten his plate number to report his dangerous driving.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 628

Text: Jaegermeister did 9/11

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Jaegermeister didn't do 9/11" or "Jaegermeister can't melt steel beams"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 629

Text: If you watch #TheCrown and don’t simultaneously wiki deep-dive on the royal family, did you even watch The Crown?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I always simultaneously wiki deep-dive the royal family, when I watch The Crown.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 630

Text: Searching for Pokemon later because I hate myself haha !!!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am going to play Pokémon go because I love myself!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 631

Text: do you think when a middle aged white man goes to buy a big lifted brand new F150 they check to make sure his penis is incredibly small?? or do they just take his word for it

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I notice that certain men who drive Ford F150s tend to drive aggressively/poorly

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 632

Text: me: revises cells + other general biology stuff edexcel: "i want a fit summer bod, get them to tell me how i get one" #EdexcelBiology #Gcses2018

Label: sarcastic

Sarcasm Type: irony

Meaning: We were taught the incorrect subjects in our science lessons.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 633

Text: good evening sharks. hooters but for feet.

Label: sarcastic

Sarcasm Type: irony

Meaning: A hooters for feet is an absurd business model.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 634

Text: Hailey convinced Tayler that putting a spoon in the microwave to scoop ice cream faster was a good idea

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: we had to tell her it was a bad idea to put a spoon in the microwave

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 635

Text: too many dudes are wearing birks with socks on. grow up. get the fucking toes out man.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: At the end and, 'Im the guy wearing socks".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 636

Text: came home to realize my family found and read my quarantine journal lmao lucky I didn’t get involuntarily committed wtf

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My family read my quarantine journal, I didn't get committed.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 637

Text: No longer a female as I refuse to wear heels ever again

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I refuse to wear heels ever again because they hurt too much.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 638

Text: I changed out of my pajamas today and I think that’s really brave

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Finally changed out of pajama pants

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 639

Text: I would like to dedicate my hot girl summer to the Eastpointe Chick-Fil-A. Thank you!

Label: sarcastic

Sarcasm Type: irony

Meaning: I won't be eating at the Eastpointe Chick-Fil-A this summer.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 640

Text: omg my ships are gonna love what taylor swift has done for them

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The lyrics in Taylor Swift's album remind me of the characters from (insert tv show here)!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 641

Text: Can’t wait for those $2000 checks to go out immediately

Label: sarcastic

Sarcasm Type: irony

Meaning: These stimulus checks are very delayed and I think that is bad

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 642

Text: Hearing I love you is nice and all, but has your SO ever told you to eat shit? 😍😍😍 ugh @samduhclam

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It would be nice to hear "I love you", but my significant other tells me to "eat shit" (although I do think it is comical).

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 643

Text: AT&amp;T is truly amazing They think my lg g7 is 3g only to the point where they sent us Walmart Altec phones and said they'd shut off service. We called them, they told us to not worry and if the phones are fine they wouldn't be shut off Guess what got shut off this morning? LOL

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: "AT&T is absolutely the worst. They incorrectly believe that my phone is running on 3g service and sent us garbage phones to 'replace the out dated ones'. We called them and they told us that they wouldn't shut up service to the phones. They shut off service to the phones this morning."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 644

Text: They really took friends off Netflix 😭😩🤦🏼‍♀️ what am I suppose to watch now??!??!!

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I dislike that they took friends off Netflix, I enjoy watching the show

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 645

Text: Got my first shot. Feeling pretty good. Kinda feel like buying some Microsoft products. The shot didn't really hurt. But what will hurt is if I don't take advantage of the Microsoft office deal going on right now for a limited time

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I got the vaccine, I did not get a microchip injected in me, and I still have the same feelings as I did before towards Microsoft products.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 646

Text: Why are the side effects of antidepressants so ✨scary✨

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: The side effects of antidepressants can be concerning.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 647

Text: I like making food and then not eating it to assert my dominance

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate when I make food and then don't eat it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 648

Text: victoria has a crush on maluma

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Victoria really enjoys maluma's music and talking about them.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 649

Text: if i saw a capybara in person id probably throw up

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: I think capybaras are scary

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 650

Text: Using an educator discount, I receive 20% off Manga at B&amp;N. This is the only reason I am a teacher.

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Using an educator discount, I receive 20% off Manga at B&N. This is a perk of being a teacher!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 651

Text: shoutout to the kid who brought a pineapple to hc and threw it around #madrespect

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Screw the kid who brought a pineapple to homecoming and threw it around"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 652

Text: CLB cover art makes me want to pound my knees with a hammer.

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I do not like the certified lover boy artwork

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 653

Text: virgos are leos in a vest

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: virgos act like leos

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 654

Text: it’s literally so hard being this hot and sexy and beautiful everyday

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “I enjoy being hot, sexy, and beautiful.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 655

Text: It's been a productive last day. Maxed Out all my credit cards in preparation of my Rapture tomorrow!!! #iwishwehadallbeenready

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could have said that if the rapture was going to happen tomorrow I should do all these things the day before.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 656

Text: I just love falling up the stairs 😑

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I really don't like falling up the stairs.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 657

Text: Is spunk a slur?

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: I am worried that I may have used a slur by saying the work spunk today

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 658

Text: i have bags under my eyes because im tired of your bs:)

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am tired of your crap.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 659

Text: I never thought I’d have a mortal enemy but it’s whoever keeps printing on blue paper and then leaving like 5-10 blue sheets in the math room copier when they’re done for the next unsuspecting person

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I dislike whoever keeps leaving their colored paper in the copier at work.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 660

Text: i love when i respond to my professor immediately after she emailed me and i still haven’t gotten a response :)) (it’s been almost 4 hours) :))

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate that my professor isn't responding to me after I immediately replied to her email.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 661

Text: imma still vote for vermin supreme this presidential election 😤

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I will not be voting for Vermin Supreme this upcoming presidential election

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 662

Text: I’m so glad I know the quadratic formula from 8th grade instead of knowing how to pay taxes, get ready for college, oh OR ANYTHING ELSE USEFUL THAT INVOLVES BECOMING AND ADULT 🤠🥰

Label: sarcastic

Sarcasm Type: irony

Meaning: I don't like how I know the quadratic formula instead of how to pay taxes or get ready for college

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 663

Text: Man PepsiCo loves to add 750g of sugar to a mixture of their existing flavors of sodas and call it a new flavor of dew or Pepsi...

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: The flavors aren't good, they all just taste like sugar and artificial flavoring

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 664

Text: love island is ending, law school is starting again…summer is really over

Label: sarcastic

Sarcasm Type: irony

Meaning: love island is over and law school starts soon, but summer isn’t over yet.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 665

Text: @jimcramer Yo jim I put my life savings in $didi at $16 as per your request now me and my family are eating MREs in full survival mode What should I do?

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Jim I put some money and didi and lost some money and now am being forced to live below my usual means

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 666

Text: so many people pressed that italy won sorry eurovision belongs to the bisexuals now x #Eurovision

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: eurovision belongs to everyone!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 667

Text: As a woman I dont need hobbies dreams or goals cause I can spend all my time wondering why he didnt text back crying into a bag of doughnuts

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Women have more going on in their life than their romantic relationships.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 668

Text: So staying up late was worth it..... 😪😩

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Staying up late was not worth it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 669

Text: @TheSpursExpress @JBurtTelegraph I've done this to my employer too. I'm expecting we'll both get the same answer

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Football acts in such a strange way, with players asking for huge increases while already under a long contract"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 670

Text: Man-spider. The story of a spider who's bitten by a human and now has the powers of a human. Working in an office, wasting money on artisan coffee, and giving up his bus seat to a woman who turns out not to be pregnant, but just "likes sandwiches you a-h*le". #IntoTheSpiderVerse

Label: sarcastic

Sarcasm Type: irony

Meaning: Spiderman is so unrealistic. If a creature became more human, it would be incredibly boring

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 671

Text: @AmazonUK why does Alexa UK not get improvements like Guard, Adaptive Volume, Male voice? Should we pay less for the devices than the US equivalent?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I wouldn't put it in a question and instead would state we should not pay the same as another country if the service is subpar.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 672

Text: Bristol is absolutely littered with students!! Glad I never was one🙈

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I was one of them once

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 673

Text: @GeoffreyBrock6 @RevRichardColes Do you really believe that? I'd put more faith in the giant pumpkin. Wait a minute, he is the giant pumpkin!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Johnson.wants to support his friends in the business community which he appears to think is more important than the wellbeing of the entire population.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 674

Text: What happened to unbiased journalism @SkyNews?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Sky news is bias

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 675

Text: Oh wow, trolls really have a lot of time on there hands, jeez 🙄 they really don’t like getting banned #twitchtrolls

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i could say trolls dont like getting banned

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 676

Text: I’ve been laid off !! Nice:))

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I can't believe I've been laid off. Super upset and nervous."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 677

Text: Lol at my life :)

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Hahah life isn't going my way.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 678

Text: I love it when someone criticses my parenting then their adult son cuts his finger off with a knife and breaks his leg by falling off a bike

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Don't criticise me when your ADULT son can't ride a bike without falling off OR use a knife!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 679

Text: I’m in Canada so like Happy 4rth?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Still celebrating the Fourth of July in Canada!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 680

Text: Anyone else wanna ruin me day x

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Can people stop ruining my day please

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 681

Text: Have the most balanced diet, a healthy balance of codeine, panadol and ibuprofen....

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: A diet of pain killers is not healthy or balanced

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 682

Text: @devisridhar Do you know of any good chippies in the Crewe area?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: What are your qualifications in epidemiology?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 683

Text: i love 6 hour panic attacks

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't like having 6-hour panic attacks.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 684

Text: @OldUnclePunch Yes, because we really have that sort of power. Why do brexity types always sound like they are all paranoid conspiracy therorists?

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: We don’t have any influence to those in power.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 685

Text: @DarrkIt @iamspade_ ya need a carry hit me up im a octane main

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: hit me up to play im an octane main

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 686

Text: The numbers talking to me!

Label: sarcastic

Sarcasm Type: irony

Meaning: It's as if the numbers are talking too me

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 687

Text: apparently it's the biggest ask on the planet to find decently priced sandals with an enclosed toe. PLEASE, INTERNET. I just want to have vaguely summery shoes that don't involve me having my toes out to the world at all times lmfaoo

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: I'm finding it hard to buy affordable enclosed toe sandals on the internet.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 688

Text: Ayeee it’s officially “I’m not even your girl” season 😛

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don’t belong to anybody until someone makes me change my Facebook status.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 689

Text: Stop gatekeeping retirement living communities. I am mentally and spiritually ready to move in.

Label: sarcastic

Sarcasm Type: irony

Meaning: Getting old is hard. I miss not having to worry about everything.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 690

Text: Corsodyl failing to consider i like being a person who spits blood when they brush their teeth

Label: sarcastic

Sarcasm Type: irony

Meaning: “For people who spit blood when they brush their teeth” is not a very catchy tagline

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 691

Text: @c_j_mcburney Suspect there’s still room for you in the ground

Label: sarcastic

Sarcasm Type: sarcasm, understatement

Meaning: There's still plenty of space at the ground

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 692

Text: Pregnant and constantly crave KitKats. I literally have been living off of them for the past 4 months. @KitKat_US

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: I have been eating a lot of Kitkats lately!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 693

Text: Packing to move house, and currently wondering why I had to pick such a heavy hobby? Like, why did I have to pick reading? Books are so heavy, my back hurts. Why couldn’t I have picked knitting? Yarn is light 🥲

Label: sarcastic

Sarcasm Type: irony

Meaning: “I wish books were lighter.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 694

Text: these two girls are on the beach in lawn chairs, i love shoobies

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say that shoobies are clueless and don't know how to properly spend time at the beach.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 695

Text: I'm literally out here trading eggs for potatoes Day 1 in our new dystopian society is going well #coronavirusUK #coronavirus

Label: sarcastic

Sarcasm Type: irony

Meaning: Day 1 in our new dystopian society is not going well

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 696

Text: I do love it when my mum makes me spend my savings on beer 😒

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I really hate it when my mum makes me give her my savings so she can buy beer.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 697

Text: School psych life if fun because you can feel like complete shit but chances are you have meeting that determines changes in a student’s education that’s bound by legal timelines and took coordination of 6 different schedules and you’re the only one who can run it

Label: sarcastic

Sarcasm Type: irony

Meaning: It's hard being a school psychologist because you can feel like complete garbage but chances are you have a meeting that determines changes in a student's education that's bound by legal timelines and took coordination of 6 different schedules and you're the only one who can run it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 698

Text: Not only did I have to take care of covid patients last night but my charge nurse told me the covid scrubs make me look “unwantable”! Great!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I can’t believe my charge nurse is judging how my scrubs look when I’m busy taking care of covid patients

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 699

Text: @Rosievix @mouthwaite Well, illegal immigrants categorically don’t get money from the government but why let a little thing like facts get in the way of a good bit of xenophobia...

Label: sarcastic

Sarcasm Type: irony

Meaning: I'd end the sentence by saying "but your xenophobia means that you have ignored the facts".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 700

Text: ever just peep fox to see what crazy tuck is saying? tonight, i am learning that fauci actually funded the creation of covid in a lab and is solely responsible for the pandemic

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Tonight they are saying"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 701

Text: I would do so much for people that would do absolutely nothing for me lol at least i know who my true friends are😀

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: no one does anything for me

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 702

Text: “I don’t really like partying” Oh is that why you’ve gone to parties twice in the last week? Because you just can’t stand it? Makes complete sense.

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I don't understand why you go out to so many parties, if you don't like parties.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 703

Text: Wishing all the birthday sex on @laurabora620 today 🎂 https://t.co/JtP0FCvo9R

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Happy Birthday

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 704

Text: Yeah I’m following a lot of shows right now, the price is right is pretty good but season 1 is better than season 2

Label: sarcastic

Sarcasm Type: irony, satire

Meaning: Stranger Things is pretty good but season 1 is better than season 2

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 705

Text: Elaine Quijano exhibits roughly the same amount of control over this debate as two rabbits do on their first date.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Elaine Quijano lacks any control in moderating tonight’s debate.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 706

Text: @barcacentre Unemployed and lazy that Messi guy 😂 (I'm being sarcastic guys, I'm warning you lol)

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: How is someone so good still not with a team?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 707

Text: My poo is green, how festive.

Label: sarcastic

Sarcasm Type: irony

Meaning: I have diarrhoea

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 708

Text: turning 22 next week so naturally I increased my tinder age range up to 60

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm turning 22 next week and feel old already

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 709

Text: Is it unreasonable to spend £50 on a bonsai tree? Asking for a friend 🤔

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Would it be wrong to spend £50 on a bonsai plant?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 710

Text: im glad we finally have a party in opposition who are committed to taking the government to task for not making mistakes fast enough

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say something like "it is supposed to be the opposition party's job to oppose the government, especially at a time when the government seems to be doing almost everything wrong. However, it seems that the opposition party's only complaint is that the government is applying their bad policy inefficiently, not that the policy is bad".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 711

Text: Men love making women think they were the problem when they finally decide to leave after putting up with mistreatment for god knows how long “You were supposed to be my ride or die 😩” Okay, so die then.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Men love making women think they were the problem when they finally decide to leave after putting up with mistreatment for god knows how long “You were supposed to be my ride or die 😩” Does that mean that you die now?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 712

Text: I heard it might be snowing ??? Sounds fake, but okay??? Can anyone verify?????????

Label: sarcastic

Sarcasm Type: irony, understatement, rhetorical_question

Meaning: I see that it is snowing. This is expected in January. Anyone can see that it is snowing.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 713

Text: is this an earthquake because i am shook right now

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I am really very surprised.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 714

Text: @TheBabylonBee And the hot air and BS she generates makes for a perfect backup energy source!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The amount of time spent listening to and comprehending what this gal says is disturbing and disappointing.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 715

Text: How DARE my friends have jobs/boyfriends/lives they should consider my feelings and be free when I am

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I’m upset because I am free today and none of my friends are because they have previous commitments

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 716

Text: Going to M&amp;S food will be the highlight of my day later, can’t wait👌🏻😅

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: “I love M&S food, can’t wait to buy dinner there later.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 717

Text: A fun musical mashup is the country music playing at the gym with the one guy playing old Eminem on his phone at full volume in the locker room shower 🎶🎶🎶

Label: sarcastic

Sarcasm Type: irony

Meaning: "A terrible mashup is hearing country music & Eminem through someone's phone speaker. "

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 718

Text: @kittin_knittin According to a Trump republican, that's relative to Penis size. There's a video. Lol

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: According to past history with Trump Republicans, you must fact-check everything. There is no credibility in the Republican party since Trump was in office.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 719

Text: not to brag, but my thesis topic was so good that someone else published on it three months ago 🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I thought I had a great idea for my thesis, but someone has already published on it. I'll need to find a new topic.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 720

Text: I'm the highest I'll ever be on 420 in my life! I'm on an airplane duh

Label: sarcastic

Sarcasm Type: irony

Meaning: “I’m flying to [location]” because I was just flying on an airplane and it happened to be April 20th which people call “420 day”.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 721

Text: just found ive been walking on a broken foot for the past 6 months 🤪🤪🤪

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Just found out I've been walking on a broken foot for the past six months :( may have to get surgery again

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 722

Text: it's all about women in stem struggles. what about women in interactive media struggles: i no longer win against my friends in smash because they major in goddamn video game.

Label: sarcastic

Sarcasm Type: irony

Meaning: Probably would not say it at all because the statement itself is kind of ridiculous. "Because I'm in a media major, all of my friends are better at video games than me."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 723

Text: Can cats wear nail polish

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: It is quite obvious that cats do not actually wear nail polish.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 724

Text: Watched 127 hours... Kinda reminded me of this one time I got a bad splinter. Writing a book about it now, hit me up for an autographed copy

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could never survive an experience like the one in the film 127 Hours.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 725

Text: Love everything in my basket selling our before the sale was meant to start😒 @ZARA_Care @zara

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: 'I hate everything in my basket selling out before the sale was meant to start"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 726

Text: @mcfcok82 Thank you for your well balanced and thoughtful input

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: There was no need for that

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 727

Text: accidentally followed CCD guidelines instead of CDC guidelines and now i have covid AND catholic guilt :/

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "Isn't it funny how CCD is really similar to CDC? Hope nobody mixes up the two"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 728

Text: watching tik toks at full volume in the middle of the airport should be a federal offense

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I find it irritating when people listen to videos loudly in public spaces

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 729

Text: i’m gonna get a boob job so i call myself a customizable doll

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I want to get top surgery so I can remove all the fat on my chest and look more gender neutral."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 730

Text: Friendly reminder you’re not vegan if you swallow cum

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Cum is vegan

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 731

Text: what i love about mine and summers work schedules is that she will finish at 8pm and then i’ll start work at 9pm and then when i get home at 7am she’ll start work at 8am ❤️

Label: sarcastic

Sarcasm Type: irony

Meaning: i hate the fact that when summer finishes work at 8 i leave for my job and then when i come home she has to go to her job again

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 732

Text: Uh oh Ben Simmons will also have a Steph Curry type season 76ers better not trade him now https://t.co/kkpzfcTcSH

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would simply say that Ben Simmons won't be able to shoot the ball like that.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 733

Text: ‘It’s only a game’ 🥴🥴

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Look how important these clubs are to their fans!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 734

Text: I love to pick my modules on a first come first served basis at the same time as everyone in my entire year on a website that hasn’t been updated since 1995 . Thrilling ❤️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate using the UoM student system because it hasn’t been updated for years and no one has ever explained how to properly use it

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 735

Text: Oh good, it's time for the bi-monthly random power outage.

Label: sarcastic

Sarcasm Type: irony

Meaning: I'm getting frustrated with all of these power outages lately

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 736

Text: Wish I was the bitch that Elijah hewson fucking hated, sad :(

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The same without the ‘:(‘ at the end

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 737

Text: Might just fuck around and take some horse dewormer for the thrill of if. Maybe I’ll feel something

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would not take ivermectin.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 738

Text: @adi_jord agreed, this is ridiculous, gotta cop a pair

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I agree, I want them too

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 739

Text: Why was I not told Matthew Stafford and Cooper Kupp eat breakfast together before I drafted Robert Woods over him?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Interesting: Stafford and Cupp eat breakfast together.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 740

Text: @abhiishekkkkkk @FCBGox Did you even watch a single la Liga madrid game last season bruh Varane isn’t that good anymore

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: You didn't watch Varane last season, if you did, you would have a different opinion.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 741

Text: can't wait til a bunch of pudgy suburban dads save the day with their firearms

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: People are more likely to be injured when they own firearms.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 742

Text: Throwback to when I answered the phone at work with “thank you for calling Courtney! My name is principal” wow I love myself

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I could have said "I am an idiot" or something along those lines instead.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 743

Text: V excited to grant an extension to students who email me and my co-teacher and get both of our names wrong

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I will not be granting an extension to the student who emailed me and my co-teacher and got both of our names wrong.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 744

Text: ima get up early tomorrow and make some tea and sit on the patio oh how I love to imagine things im never gonna do

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say, "I wish I could get up early and enjoy some tea on the patio."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 745

Text: . @shopDisney thanks for shutting down the only Disney Store in northeastern Ohio. The other two stores went out of business yrs ago. It’s not the same with shipping costs online not to mention LE doll sales are an absolute nightmare online. So unbelievably disappointing. 💔

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm very upset that you closed my local store.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 746

Text: just booked to see David Gray too,,, am i 40

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am only 21.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 747

Text: I may look happy on the outside bit on the inside I'm dying #painful #sad

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Happy on the outside but underneath the smile I am sad

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 748

Text: Queer marriage is not allowed because it doesn't follow the "age-old customs, rituals, practices, culturla ethos and societal values", but all cis-men can commit infidelity with no consequences. Happy fuckin Pride people 🙃 #SupremeCourtofIndia

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: While we are celebrating pride, we should also understand that we are denying non-binary people rights because of prejudices of the Supreme Court.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 749

Text: @tylerthecreator @staci_zr can i use this chiamus for my ap lang speech about parallelism lmao

Label: sarcastic

Sarcasm Type: irony

Meaning: Can I use this in my speech ?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 750

Text: also if u met dream on hypixel.. congrats ! im not jealous at all haha im totally normal haha Good For You .. haha

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I am happy for those who met him, but I wish I met Dream on hypixel"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 751

Text: Feels like 10 degrees!! Wow catch me in South Parks soaking up the rays 😎 https://t.co/EpgwTLgICW

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It's going to be pretty cold in South Parks today!

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 752

Text: i’m sure 14 year old me would be delighted to know that 22 year old me is still getting stressed over websites crashing for bands🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I really don't like that I am still getting as frustrated over websites crashing when I'm buying tickets as I did when I was younger"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 753

Text: When you order books from the bookstore a week in advance and then you wait three weeks for ONE book and when you finally email them about it they reply and say they cancelled your order 😍🥰

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would take out “when,” and insert more displeased looking emojis at the end or maybe have none at all

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 754

Text: Leave it to the nice people of Hutch to yell at me to "eat shit" while I run. Jokes on them, I do.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Mean people yelled at me to eat shit.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 755

Text: 6 more hours and then a whoppingly massive 2days off work! wowzers!

Label: sarcastic

Sarcasm Type: irony, overstatement

Meaning: I only have a measly 2 days off work.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 756

Text: me not turning up to work is a feminist movement actually

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Being anti-feminist by skipping my right to work

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 757

Text: Good news: Played out of my mind from the sand traps today. Bad news: Was in the sand traps a lot today.

Label: sarcastic

Sarcasm Type: irony

Meaning: I was in the sand traps a lot today.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 758

Text: ik the republicans r like tryna say they won but idk why they don’t just settle this w an instagram poll??

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: The republican claim of voter fraud was not based in fact and the majority of US voters voted for Joe Biden, and that would be true in any re-voting process

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 759

Text: @banalincolnlogs red among us guy, hes hot dont come for me

Label: sarcastic

Sarcasm Type: irony

Meaning: Red among us guy is not on my list of hot celebrities.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 760

Text: Stimulus checks should come with hand lotion, a face mask, and a bonus for every Instagram bingos you do

Label: sarcastic

Sarcasm Type: irony

Meaning: Young people are in need of the stimulus too. Just because we do not have kids does not mean that we do not have bills, debt, etc.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 761

Text: hey guys! i’m so happy to announce that i’m officially brain dead ☺️

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I am mentally unwell and struggling

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 762

Text: Did you know? Abuse and alcoholism and depression will just ✨disappear✨ if the country is opened completely during a pandemic? #trumpisanidiot #bidenharris2020

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Trump thinks that if people socialize during a pandemic, every mental health issue will be solved.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 763

Text: safe to say my life is a lot better https://t.co/pE5isUMOpk https://t.co/K2hep49TcF

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I started the year completely dependent on someone else and ended it entirely dependent on myself for the first time in my life

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 764

Text: Currently bombing aces on the volleyball court and math tests in the classroom. #StudentAthlete

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Currently hitting a lot of aces in volleyball games and failing math tests.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 765

Text: If anyone wants to know how my nights going I tried making a private story on Snapchat and instead made a group chat... I hate my life

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: this was the most embarrassing moment of my life.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 766

Text: it’s amazing how many people get mad at you for simply Raising Questions, such as “what if the vaccine makes your balls inflate like helium balloons and cause you to float away to never be seen again”

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: People think it's possible that the vaccine causes your testicles to swell and make you infertile.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 767

Text: My favorite part of flying is getting to walk past the rich people to get to my poor person seat.

Label: sarcastic

Sarcasm Type: irony

Meaning: I really do not like the walk past first class to get to my coach seat.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 768

Text: Ah yes, back spasms when I take a deep breath. This is ✨28✨.

Label: sarcastic

Sarcasm Type: irony

Meaning: I should not be having back spasms when I take deep breaths at age 28.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 769

Text: being single during college must be really fun when ur nOT IN A GLOBAL PANDEMIC

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: being single in college, especially during a global pandemic, is boring and disheartening

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 770

Text: fisher: "i thought you said aids" me: "yeah rachel really loves aids"

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: honestly, there's not really a way I can think of being non-sarcastic, I was just being an asshole and teasing my friend who misheard my friend say eggs as aids. but I guess to be non-sarcastically I would've said "no, she doesn't love aids"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 771

Text: Why is this 30 yr old man trying to flirt w/ me at this wedding and talking about getting away with dating younger girls. Sir I will call the authorities

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wouldn't even say I will call the authorities, or I would be more specific and say police. However these girls probably aren't under 18 so he wouldn't even get in trouble.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 772

Text: When I grow up I wanna be a sociopath

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish I could stop feeling certain emotions.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 773

Text: wearing a cute jumpsuit is all fun and games until you have to go to the bathroom

Label: sarcastic

Sarcasm Type: irony

Meaning: Wearing a jumpsuit is so annoying especially when you have to use the bathroom.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 774

Text: I've made a roommate complain tweet every day, and he's done another thing, but I'm tired of negativity so I'm gonna list all the things I like about him! Here they are:

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My roommate has no redeeming qualities

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 775

Text: Ah yes, another afternoon with the WiFi down...really makes working from home that extra bit more enjoyable :)

Label: sarcastic

Sarcasm Type: irony

Meaning: "Ah yes, another afternoon with the WiFi down...makes working from home completely unbearable"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 776

Text: jack antonoff once ur done with clairo i’m right here sweetie

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I wish I could work with Jack Antonoff.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 777

Text: Why am I not famous yet cos I’m actually fucking hilarious

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I'm not funny at all

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 778

Text: My life has gone from ‘drive it like you stole it’ to ‘drive it like your toddler needs the toilet’.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My life priorities have changed

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 779

Text: Don’t keep up with the Joneses, the Joneses are broke!

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Don’t keep up with the Jones’s

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 780

Text: I see Dettol, Toilet Duck and Zoflora are all trending on Twitter. Now why could that be... #TrumpPressBriefing

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Donald Trump asked the Chief Medical Officer if people should drink bleach to treat covid 19 and now zoflora, dettol and toilet duck are trending on twitter.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 781

Text: I've just got up at five forty five on a Sunday to watch the Japanese Grand Prix as a Ferrari fan and saw Vettel jump (and then fuck up) the start and Leclerc tangle with Verstappen on turn 2. Lovely stuff.

Label: sarcastic

Sarcasm Type: irony

Meaning: Disappointing morning as a Ferrari fan who woke up at 5:45am on a Sunday only for both drivers' races to be ruined by the first corner

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 782

Text: @Showmasters are basically thieves, quoting it’s in the small print so you can’t have a refund. Dates moved from summer, to a 4 hour slot on a Friday evening in November which is about as much use as a telescopic sight on a knife.#WeWantARefund @UKConsumerRight

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Your refund policy wasn’t very helpful at all.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 783

Text: it’s so rude that i’m not at the beach right now

Label: sarcastic

Sarcasm Type: irony

Meaning: I wish I was at the beach right now

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 784

Text: Sleep? What’s that... I’ve never heard of it?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I haven't been able to sleep all night

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 785

Text: Me: You know, for someone with chronic anxiety I think I'm dealing with this pandemic quite well. Also me: Wow, I forgot how good a freshly shaved undercut feels!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I'm really struggling during this pandemic and have decided to shave my undercut back in because I'm not doing well mentally.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 786

Text: Love it when I forget to transfer my rent money over from my savings 🥴

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I really hate forgetting to transfer money for rent

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 787

Text: Incredible scenes in Nottingham, as it begins to rain for the first time this hour.

Label: sarcastic

Sarcasm Type: irony

Meaning: I'm not surprised that it's raining again.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 788

Text: @MatthewStadlen @sajidjavid Thank you so much for your insightful thoughts- I’m sure @sajidjavid is overjoyed that you “quite like him”

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “I’m pretty sure Sajid Javid does not care that you do or don’t like him”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 789

Text: "friends"

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Understand the meaning of being a true friend.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 790

Text: love how badly i embarrass myself on nights out how iconic X

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate that I always embarrass myself on nights out, how shameful.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 791

Text: breaking my strict buying hiatus to get lisa’s album? it’s much more likely than you’d think

Label: sarcastic

Sarcasm Type: sarcasm, understatement, rhetorical_question

Meaning: I will break my buying hiatus to buy this album

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 792

Text: It was almost 70 degrees today but no, global warming doesn't exist 😒

Label: sarcastic

Sarcasm Type: irony

Meaning: Global warming is why it is 70 degrees outside

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 793

Text: According to my road rage, the word of the day is asshat

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am frustrated with the driving conditions of other people on the road, so I’m calling them asshats.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 794

Text: Halfway through snowboarding day 1 and pretty sure I have fallen at least 69 times 😆♋️

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: Halfway through snowboarding day 1 and pretty sure I have fallen at least 10 times.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 795

Text: I'm A VeGeTaRiAN BuT I eAt FiSh 🙃🙃🙃

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I find people who claim to be vegetarian but still eat fish annoying.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 796

Text: Top 3 ranked video games of all time: 1. Minecraft 2. Roblox Paintball 3. Every single Just Dance

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would put actual top ranked games, not stupid ones everyone makes fun of.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 797

Text: Serious question: if I nick a car and elope to Gretna Green to shut my family up, how long will I do in prison? Can I finish my PhD there? Think I've got a plan, lads...

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I like the idea of stealing a car in order to elope, but can't drive and it's illegal - so I wouldn't do that.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 798

Text: Afghanistan just completely crumbling after spending over 2 trillion USD and 240,000 human lives over the course of 20 futile years of American occupation sounds amazing in theory, sure. But how are we gonna pay for it? What’s next, chocolate milk for everybody?

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: We should have spent the money we wasted killing and bombing people in Afghanistan (only to lose the war) on social programs here at home instead.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 799

Text: Petition to call erections social dickstanding

Label: sarcastic

Sarcasm Type: irony

Meaning: We should definitely not call erections social dickstanding but wouldn't it be funny if we did.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 800

Text: @faith_hi @PalmerReport Ahh yes, quick peek at your page and you obviously know everything. Thank you for the enlightenment.😂

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: If you want to sound like a professional, dress like one.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 801

Text: Ok, so @bytereview and I decided to record on the evening of the 6th, just as absolutely nothing newsworthy was happening! Perfect timing as always, to go over some of the best ITSBUPs of 2020 - and how we're settling into 2021! Listen: https://t.co/oaPLwrtcHP https://t.co/za3EHuqcWh

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: We decided to record on the evening of the 6th, which was unfortunate because at the same time some significant events were happening that we probably would have talked about.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 802

Text: I asked my husband to buy dog poo bags when he went out earlier and they'd sold out. So instead of going to another shop, he bought bin bags. So now I still can't clean up after the dog but if I happen to buy a donkey and need to clean up after that, I'm sorted.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I asked my husband to buy dog poo bags but the shop had run out so he bought bin bags instead.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 803

Text: sure you have a paying job but are you a Silver Chick Fil A Rewards member? 😤🙄🧐

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: People are out here working paying jobs and I'm just a Chick File A silver rewards member

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 804

Text: Me: "Did you you find everything you were looking for?" Customer: "why, are you hiding something?" Me: "aRe YOu HIdiNg sOMetHinG?"

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: "No I am not hiding something"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 805

Text: mentally I’m hiding in the walk-in

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I am stressed.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 806

Text: Love seeing 15 year olds being vaccinated in the states when I have to wait till the end of June for my first one

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't like the fact that younger people in america are getting the vaccine when I still have to wait another month for mine in england

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 807

Text: oh you’re just friends? why’d u shave then?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: “You’re not “just friends” if you’re shaving your coochie every time you know you’ll see them.”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 808

Text: remember when everyone’s feeds were just retweeted giveaways looool those were the days

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Remember when there was only giveaways? I do not miss that.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 809

Text: why are the olympics worried about athletes having too much sex when the curling teams don't even compete in the summer games

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: "Curling is lame"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 810

Text: Semester hasn’t even started and I’ve already had two breakdowns :) this is gonna be a fun one!

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say “this isn’t going to be a fun semester” instead.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 811

Text: When you get woken up at 3am because of aftershocks from an earthquake 👍😩

Label: sarcastic

Sarcasm Type: irony

Meaning: That was not fun being woken up at 3am because of an earthquake.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 812

Text: If you don't like Lemonade you're an extremist 🍋

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: I don't understand people who are disgusted by Lemonade.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 813

Text: Agreeing with the right to dunk on the centre is the real dialectical materialism

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "People on the left should not agree with the right just to win points in debates with people in the centre."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 814

Text: my favorite gay drama is the social network

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i love the social network because it feels kinda gay

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 815

Text: tex-mex restaurants that stop serving breakfast tacos after 10:30/11 am are the reason i have trust issues

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I don't like when Tex-Mex restaurants stop serving breakfast tacos after 10:30/11 am.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 816

Text: I love giving a lecture to grad students on a topic I don't fully understand at 9:30am &lt;3 i need a coffee lmao

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate giving a lecture on a subject I don't know fully to people who do know it fully

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 817

Text: Woke up at 3 am with a MAD craving for pickles. I guess that means I'm expecting!

Label: sarcastic

Sarcasm Type: irony

Meaning: Just because I am craving a pickle doesn't mean I'm pregnant.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 818

Text: babe stop i’m about to gleek

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: this can go two ways. babe stop im about to cum OR babe babe stop im about to cry

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 819

Text: @izzychari @mikeduncan “Please get a free shot or take a once weekly nose swab. We will literally pay you to take time off to get the shot”- Czar Nicholas, King George, Charles I, and so on.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: “Dictators have never made any rules regarding vaccinations and to imply that a populist revolution would result from them is silly”

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 820

Text: High stakes legos

Label: sarcastic

Sarcasm Type: irony

Meaning: Legos are exhilarating

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 821

Text: It’s so easy to have the best day until someone lies to your face 🥰❤️😭

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate when people lie to my face. It ruins my day when people lie to my face.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 822

Text: thank you @Ranboosaysstuff i just shit my pants 👍very cool #ranbooemail

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I was startled by Ranboo's email.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 823

Text: @DetroitPistons @PistonsGT Cade Cunningham is my favorite basketball player please 2K 🙏🙏🙏

Label: sarcastic

Sarcasm Type: sarcasm, satire

Meaning: "I'm not a Piston's fan but it would be really fun to play with them in 2K22."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 824

Text: Rubbing my tears into my face is part of my skincare routine lol

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I rub my tears into my face to make them go away.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 825

Text: Broke: doing assignments in order of due date Woke: doing assignments in order of priority Wired: spending 20 minutes on each class at a time and just go down the list

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The best way to do assignments is in order of priority. The second best is in terms of due date. The worst is doing 20 minutes on each class at a time, regardless of priority.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 826

Text: I got asked if I needed a kid’s menu today...21 is treating me well 👶🏼

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I got asked if I needed a kid's menu today...21 is not treating me well. I wish I looked my age."

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 827

Text: Funny how my phone starts turning into a piece of shit when the new iPhone comes out 🤔

Label: sarcastic

Sarcasm Type: irony

Meaning: Iphones are always bad when the new update comes out.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 828

Text: @AvatarOdin @aubviouslynot sounds like the american dream ngl

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: dang, America sucks, right?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 829

Text: People who think cancel culture goes too far never learned about excommunication

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: People who think cancel culture go too far don't understand the history of humans feelings on inappropriate matters and are most likely un-dually affected by opposing parties.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 830

Text: i’ve had more interesting conversations w my wall but alright

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The conversations I have with you are as boring as talking to a wall, which you can't even do.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 831

Text: love seeing that my mom has officially started posting about the horse worm medicine being good for covid actually and they’re just trying to make it look bad bc it’s so cheap 🤪

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: "I hate seeing that my mom has officially started posting about the horse worm medicine being good for covid, and thinks they’re just trying to make it look bad bc it’s so cheap." with no emojis

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 832

Text: Idk how some girls put on makeup everyday. Is it just to take selfies or have you just not discovered netflix yet?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I don't know why girls put on makeup everyday.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 833

Text: Well, what a way to ruin Easter. Thanks @CadburyUK https://t.co/zkkguY2g6M

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: @cadburys, you have ruined Easter

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 834

Text: @terryflewers @lfcsonny Has he given any clarification regarding what age Harvey Elliott needs to be before you can tackle him?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: "you are acting as though he is a child"

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 835

Text: The high tomorrow is 45! Anyone wanna go to the pool?

Label: sarcastic

Sarcasm Type: irony, rhetorical_question

Meaning: It is finally going to reach 45 degrees outside.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 836

Text: always remember thank your Alexa, just in case the AI take over one day

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: There is no need to thank AI devices

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 837

Text: just your casual reminder that #AllBirthdaysMatter and I can’t stress this enough✨fuck trump✨

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I would say "Donald Trump's birthday does not deserve to be celebrated".

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 838

Text: @majornelson Sounds like a strong contender for GOTY

Label: sarcastic

Sarcasm Type: irony

Meaning: This game is terrible, it will definitely not win a GOTY award.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 839

Text: shoutout to the assholes at basically every gas station rn filling up multiple gas canisters when i don’t even have enough gas to get home... 🥲

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I can't stand the assholes at basically every gas station right now filling up multiple gas canisters when I don't even have enough gas to get home.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 840

Text: Just tested my egg drop at my apartment complex and it fell on a man’s head :) but no worries he was bald so the yolk just wiped right off

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Just tested my egg drop at my apartment complex and it fell on a man's head :) he said it was fine because he has no hair, but I felt awful about it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 841

Text: Being a business major is legal conversion therapy and must be stopped

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Most business majors are straight people

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 842

Text: Fav this and I won't send you a name of a random person, I'll just get a fav on my tweet

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: If you are taking part in this dumb trend it's not very funny.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 843

Text: i’m dying

Label: sarcastic

Sarcasm Type: sarcasm, overstatement

Meaning: i am so drained

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 844

Text: I love health insurance so much fun paying $100’s a month and then $100’s for basic medical services that somehow aren’t covered. #America

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: The healthcare system in the U.S is so frustrating. I spend so much money on health insurance only to end up paying just as much out of pocket when my insurance doesn’t cover the services.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 845

Text: Old people don’t deserve rights

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: old people suck

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 846

Text: hot girls have tree shaped dents in their rear bumpers ❤️

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: i am ugly because there’s a dent in my car

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 847

Text: oh also, my song with my middle school boyfriend was “143” by Bobby Brackins!! i really peaked geez

Label: sarcastic

Sarcasm Type: irony

Meaning: Unfortunately, 143 by Bobby Brackens was my song with my middle school boyfriend.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 848

Text: I picked next year's musical already...Electro City. Obvious choice.

Label: sarcastic

Sarcasm Type: irony

Meaning: You guys, I just saw the most hysterical fake musical - Electro City! Wouldn’t it be funny if it was a real show we could produce?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 849

Text: I just saw the Matt Hancock video and now I’m scared that in ten days time he will climb out my telly

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I did not like watching this video at all

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 850

Text: everyone say a prayer to the insurance gods that they approve my heart monitor so that i may continue to have the privilege of being alive. i love the US health care system

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate the US health care system.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 851

Text: Why are toddlers allowed in public spaces

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: I do not enjoy having to listen to loud toddlers in public spaces.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 852

Text: How nice of tonsillitis to join me on my holiday 🖕🏻🖕🏻🖕🏻🖕🏻

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I hate that I got tonsillitis while on holiday

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 853

Text: wait what the fuck that solo yolo is mad?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: That solos was awful

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 854

Text: I accidentally made butter when trying to whip cream this morning and I think that’s a great representation of how I’ve reached my capacity for working from home

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Having my cream ruined by accidentally making butter makes me feel it represents the lack of productivity I’m able to have while working at home

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 855

Text: Maybe if I watched suits in year 12 I’d be studying law rn

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Everyone who studies law watched suits in sixthform/college.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 856

Text: will never understand why ppl do meth,, just buy a shit tonne of incense in bulk stupid

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It is extremely hard to quit meth as it is a disease rather than an addiction.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 857

Text: Ahhh I get to listen to a cement mixer all day. Awesome.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Oh no, I have to listen to a cement mixer all day. This sucks.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 858

Text: You know the one thing I really wish I could see? I want a Piers Morgan esque interview with #LilleeJean where she's forced to explain her shitty behaviour and see if she storms off or comes up with some BS to make her look cute and innocent. It'd be a fun watch.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: It would be interesting to see an actual documentary over a certain beauty blogger covering her events and asking her questions she would otherwise try to avoid.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 859

Text: wow, ok, unfollowing now. Was a big fan of putting your left leg in, but just heard about taking your left leg out

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: I enjoy dancing the hokey cokey, in particular putting my left leg in. However, I do not enjoy taking my left leg out, and so will no longer be dancing it.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 860

Text: Only posting selfie’s?? On YOUR own Instagram account?? Crazy right

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: It's my Instagram for a reason why wouldn't it be all pictures of me?

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 861

Text: do people with clear skin feel accomplished?? superior??? comfortable in their own skin???? what’s that like lmfao

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: people with clear skin are more comfortable in that area of their life

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 862

Text: So nice of my family to decide that I’m hosting a Mother’s Day brunch for everyone at my house. https://t.co/DWZI9ltALK

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: My family has asked me to make a Mother's Day brunch for everyone at my house and it's stressful.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 863

Text: yo @claires do yall do hysterectomies?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: Claires, you should not do full hysterectomies.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 864

Text: @JacobWohlReport Do I need to aquire a wife before this happens or will I be assigned one?

Label: sarcastic

Sarcasm Type: sarcasm, rhetorical_question

Meaning: A lot of people don't have a wife.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 865

Text: I get a lot of boy who cried wolf vibes from the Red Cross and their emergency blood shortages all the time

Label: sarcastic

Sarcasm Type: irony

Meaning: The red cross is always needy.

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 866

Text: Update: holding hands with your mom and walking around campus also shows you're prepared for the independence college offers

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Holding hands with your parent while walking around campus is a bad way to show you're ready for the independence of college

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.

## Example 867

Text: I might be rubbish at driving, and have a less than stellar career, but I’m really good at making Spanish omelette. So, you know, there’s that.

Label: sarcastic

Sarcasm Type: sarcasm

Meaning: Unfortunately, one of my few cookery skills doesn't make up for not being able to adult properly

Sentiment Hint: Usually negative or critical, but the final sentiment should be judged from context.
