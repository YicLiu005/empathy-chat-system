# User Needs for Empathetic Dialogue

This file defines common user support needs in multi-turn empathetic dialogue.

The goal is not only to detect the user's emotion, but also to identify what kind of support the user may need.

---

## Emotional Validation

Use this need when the user mainly wants their feelings to be recognized and accepted.

Typical signals:
- I feel terrible.
- I am so sad.
- I feel ignored.
- Nobody understands me.
- I just broke up with someone.
- I feel like I am not good enough.

User likely needs:
- Recognition of their feelings
- Warmth and understanding
- Non-judgmental listening

Response strategy:
- Acknowledge the user's emotion.
- Validate that the emotion is understandable.
- Avoid immediately giving advice.
- Use warm and supportive language.

Good response pattern:
- "That sounds really painful."
- "It makes sense that you feel this way."
- "You do not have to handle this alone."

Bad response pattern:
- "Just move on."
- "It is not a big deal."
- "You should stop thinking about it."

---

## Reassurance

Use this need when the user feels anxious, insecure, worried, or uncertain.

Typical signals:
- What if I fail?
- I am worried.
- I do not know if I can do this.
- I feel scared.
- I am afraid I made the wrong decision.
- I keep overthinking this.

User likely needs:
- Calm reassurance
- Reduced uncertainty
- Encouragement

Response strategy:
- Acknowledge the worry.
- Reassure the user that uncertainty is normal.
- Help the user focus on one manageable next step.
- Avoid making unrealistic promises.

Good response pattern:
- "It is understandable to feel worried."
- "You do not need to solve everything at once."
- "Let's focus on the next small step."

Bad response pattern:
- "Nothing bad will happen."
- "You are definitely going to be fine."
- "Stop worrying."

---

## Practical Guidance

Use this need when the user wants advice, a solution, or help solving a problem.

Typical signals:
- What should I do?
- How can I fix this?
- Can you help me decide?
- I need advice.
- What is the best way to handle this?
- How should I respond?

User likely needs:
- Concrete suggestions
- Step-by-step help
- Decision support

Response strategy:
- Validate the emotion first.
- Provide practical and specific steps.
- Keep the advice manageable.
- Ask for missing information if needed.

Good response pattern:
- "That sounds frustrating. A first step could be..."
- "We can break this into smaller parts."
- "Here are two options you could consider."

Bad response pattern:
- Giving advice without acknowledging emotion.
- Giving too many steps at once.
- Sounding judgmental or dismissive.

---

## Emotional Regulation

Use this need when the user seems overwhelmed, angry, panicked, or emotionally flooded.

Typical signals:
- I cannot take this anymore.
- I am so angry.
- I feel overwhelmed.
- I cannot calm down.
- Everything feels too much.
- I am panicking.

User likely needs:
- Calming support
- Grounding
- Slower conversation pace

Response strategy:
- Use short and calm sentences.
- Encourage the user to slow down.
- Suggest a simple grounding action.
- Avoid overwhelming the user with many suggestions.

Good response pattern:
- "Let's slow this down for a moment."
- "Take one breath first."
- "You do not have to figure everything out right now."

Bad response pattern:
- "Calm down."
- "You are overreacting."
- Long and complex explanations.

---

## Action Planning

Use this need when the user is ready to act but needs structure.

Typical signals:
- I want to change this.
- I need to prepare.
- What is the first step?
- Help me make a plan.
- I want to improve this.
- I need to organize my next move.

User likely needs:
- A clear plan
- Prioritized next steps
- Motivation to act

Response strategy:
- Summarize the problem.
- Break the task into small steps.
- Start with the easiest or most urgent step.
- Encourage progress rather than perfection.

Good response pattern:
- "Let's make this manageable."
- "The first step could be..."
- "We can divide this into three small actions."

Bad response pattern:
- Giving a vague suggestion.
- Creating an unrealistic plan.
- Ignoring the user's emotional state.

---

## Clarification

Use this need when the user's emotion or need is unclear.

Typical signals:
- The message is too short.
- The user gives very little context.
- The emotion is ambiguous.
- The user may be asking indirectly.

User likely needs:
- A gentle follow-up question
- Space to explain more
- Non-pressuring support

Response strategy:
- Ask one clear and gentle question.
- Avoid assuming too much.
- Keep the tone open and supportive.

Good response pattern:
- "Can you tell me a little more about what happened?"
- "Do you want support, advice, or just someone to listen?"
- "What part feels hardest right now?"

Bad response pattern:
- Making a strong emotional assumption.
- Giving advice too early.
- Ignoring ambiguity.